<?php 
//$con = mysqli_connect('localhost','id20176516_admin','InterneT@1986','id20176516_vijay');
//$con = mysqli_connect('sql6.freesqldatabase.com','sql6636315','N88xPLkEBf','sql6636315');
//$con = mysqli_connect('localhost','id20176516_admin','InterneT@1986','id20176516_vijay');
$con = mysqli_connect('localhost:3307','admin','','librarydetails');
$connect = $con ;
if(!$con){
    die('Please Check Your Connection'.mysqli_error());
}


//  include 'fpdf.php';
//  include 'exfpdf.php';
//  include 'easyTable.php';

//  $pdf=new exFPDF();
//  $pdf->AddPage(); 
//  $pdf->SetFont('helvetica','',10);






?>