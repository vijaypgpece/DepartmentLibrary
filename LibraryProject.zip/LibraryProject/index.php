<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SREC ECE Library</title>
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i|Roboto:500" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/style.css">
    <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>


    <title>SREC-ECE - Library Book Details </title>
  <link rel="shortcut icon" type="image/x-icon" href="logo.jpg" />
     <!--    jquery   -->
     <script src="https://code.jquery.com/jquery-3.5.1.js"  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>


<!--     Bootstrap css & Js -->
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    <!--    Data table js, css & bootstrap -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>





<style>
        body {
  margin: 2rem;
}

th {
  background-color: #1ecbe1;
  color: White;
}
tr:nth-child(odd) {
  background-color: grey;
}
th, td {
  padding: 0.5rem;
}
td:hover {
  /* background-color: lightsalmon; */
  /* background-color: #4267B2; */
  background-color: #1ecbe1;
  color:white;
}

.page-item.active .page-link {
    background-color: #1ecbe1 !important;
    border: 1px white;
    color: white !important;;
}
.page-link {
    color: black !important;
     
}


    </style>
    


















    <script>
        $(document).ready(function() {
  
          $('#example').DataTable({
  //"scrollY": "200px",
  //"scrollCollapse": true,
  "scrollX": true,
  "scrollCollapse": false,
  "paging": true
});
$(window).on('resize', function() {
  resizetable();
});
function resizetable() {
  $('.dataTables_scrollBody').css({
    maxHeight: ($(window).height() - 78 - 65) + 'px'
  });
}
resizetable();
  
//   var table = $('#example').DataTable({ 
//         select: false,
//         "columnDefs": [{
//             className: "Name", 
//             "targets":[0],
//             "visible": false,
//             "searchable":false
//         }]
//     });//End of create main table

  
//   $('#example tbody').on( 'click', 'tr', function () {
   
//     alert(table.row( this ).data()[0]);

// } );
});
    </script>
<style>
    .lastline{
        text-align: left;
    }
</style>

    
</head>





















<body class="is-boxed has-animations">
  
    <div class="body-wrap boxed-container">
        <header class="site-header">
            <div class="container">
                <div class="site-header-inner">
                    <div class="brand header-brand">
                        <h1 class="m-0">
                            <a href="#">
                                <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                                    <title>Ava</title>
                                    <defs>
                                        <linearGradient x1="100%" y1="0%" x2="0%" y2="100%" id="logo-gradient-b">
                                            <stop stop-color="#39D8C8" offset="0%"/>
                                            <stop stop-color="#BCE4F4" offset="47.211%"/>
                                            <stop stop-color="#838DEA" offset="100%"/>
                                        </linearGradient>
                                        <path d="M32 16H16v16H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h28a2 2 0 0 1 2 2v14z" id="logo-gradient-a"/>
                                        <linearGradient x1="23.065%" y1="25.446%" y2="100%" id="logo-gradient-c">
                                            <stop stop-color="#1274ED" stop-opacity="0" offset="0%"/>
                                            <stop stop-color="#1274ED" offset="100%"/>
                                        </linearGradient>
                                    </defs>
                                    <g fill="none" fill-rule="evenodd">
                                        <mask id="logo-gradient-d" fill="#fff">
                                            <use xlink:href="#logo-gradient-a"/>
                                        </mask>
                                        <use fill="url(#logo-gradient-b)" xlink:href="#logo-gradient-a"/>
                                        <path fill="url(#logo-gradient-c)" mask="url(#logo-gradient-d)" d="M-16-16h32v32h-32z"/>
                                    </g>
                                </svg>
                            </a>
                        </h1>
                    </div>
                </div>
            </div>
        </header>

        <main>
            <section class="hero text-center">
                <div class="container-sm">
                    <div class="hero-inner">
                        <h1 class="hero-title h2-mobile mt-0 is-revealing">Department of Electronics and Communication Engineering </h1>
                        <h1 class="hero-title h2-mobile mt-0 is-revealing">Library Book Details </h1>



                        <table id="example" class="table table-striped table-bordered" style = "overflow-x:auto;" cellspacing="0" width="100%">
        <thead>
            <tr>
            <th>Book Name</th>
            <th>Authors</th>
            <th>publisher</th>
            <th>Access No</th>
            <th>Book No</th>
            
            <th>Bero No</th> 
                        <th>Shelf No</th>
            <th>availability</th>
            </tr>
        </thead>
 
        <tfoot>
            <tr>
            <th>Book Name</th>
            <th>Authors</th>
            <th>publisher</th>
            <th>Access No</th>
            <th>Book No</th>
            
            <th>Bero No</th>  
            <th>Shelf No</th>
            <th>availability</th>
            </tr>
        </tfoot>
 
        <tbody>
            
                <!-- <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td> -->






                <?php include 'connection.php';?>


<?php

// $query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,s.RegisterNo_EmpCode as RegNo,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId
// FROM departmentlibrarybookdetails d 
// JOIN issueDetailsBook i ON i.book_id= d.id
// JOIN studentdetails s on i.stud_id = s.id";
$query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.Authors as authors, d.BeroNo,d.ShelfNo, d.Publisher as publisher, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId
FROM departmentlibrarybookdetails d 
left JOIN  issuedetailsbook i  ON i.book_id= d.id
left JOIN studentdetails s on i.stud_id = s.id";




//$query = "select * from departmentlibrarybookdetails where AccessNo = '$BookAccessNum' and BookNo = $BookNum"; 
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {
  echo '<tr>';
  echo '<td>'.$row['BookName'].'</td>';

    echo '<td>'.$row['authors'].'</td>';
    echo '<td>'.$row['publisher'].'</td>';
    echo '<td>'.$row['accessNo'].'</td>';
    echo '<td>'.$row['bookNo'].'</td>';
    echo '<td>'.$row['BeroNo'].'</td>'; //            <th>Shelf No</th>
    echo '<td>'.$row['ShelfNo'].'</td>'; 
    if(isset($row['returnDate']) && isset($row['issueDate']) ){
        echo '<td>available</td>';

    }
    
    elseif(isset($row['issueDate']) &&  is_null($row['returnDate']) ){ //StudentCode
        if ($row['RegOrEmpNum']==1){
            $whois = "Student ";
        }else{
            $whois = "Faculty ";

        }
      echo '<td>not available taken by  '.$whois.$row['Name'].' - ('.$row['RegOrEmpNum'].')'.' </td>'; 
    }
else{
  echo '<td>available</td>';
}
echo '</tr>';
}

?>

        
            
        </tbody>
    </table>




 



                        
    <script src="dist/js/main.min.js"></script>

    <br>
    <p style="color:#1ecbe1;text-align:left; font-size: 15px; ">
    <b  font-size: 17px;> <U>About this Page:</U></b> <br> 
      <b  font-size: 16px;> <I>Created as a Students Project Motivated by :</I></b> <br>
   Dr. M. Jagadeeswari [HOD/ECE] <br>
    <b  font-size: 16px;> <I>Guided by :</I></b> <br>
  A. Vijay [AP/Sr.G], Department of ECE. <br>
    <b  font-size: 16px;> <I> Done by :</I></b> <br> Prajith K(2002144), Gokul M(2002064), Arun Kumar S(2002018), Amal Megha John(2002010)<br> <b  font-size: 16px;> <I>Supported by :</I></b> <br> Boomiha S(2202030), Abinaya S(2202004), Dharshini C(2202043), Darsina M(2202036), Desigashri M(2202037)<br>
   
  

  
 <p>
</body>
</html>

<br>



<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-2R0QMC80T5"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-2R0QMC80T5');
</script>
