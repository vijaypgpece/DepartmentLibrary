<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Easy access to availability of Books">
    <title>SREC-ECE - Library Book Details </title>
  <link rel="shortcut icon" type="image/x-icon" href="logo.jpg" />
     <!--    jquery   -->
     <script src="https://code.jquery.com/jquery-3.5.1.js"  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>


<!--     Bootstrap css & Js -->
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    <!--    Data table js, css & bootstrap -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <style>

















        body {
  margin: 2rem;
}

th {
  /* background-color: white; */
  background-color: #CBC3E3;
}
tr:nth-child(odd) {
  background-color: grey;
}
th, td {
  padding: 0.5rem;
}
td:hover {
  background-color: lightsalmon;
}

.paginate_button {
  border-radius: 0 !important;
}





    </style>
    <script>
        $(document).ready(function() {
  
          $('#example').DataTable({
  //"scrollY": "200px",
  //"scrollCollapse": true,
  "scrollX": true,
  "scrollCollapse": false,
  "paging": true
});
$(window).on('resize', function() {
  resizetable();
});
function resizetable() {
  $('.dataTables_scrollBody').css({
    maxHeight: ($(window).height() - 78 - 65) + 'px'
  });
}
resizetable();
  
//   var table = $('#example').DataTable({ 
//         select: false,
//         "columnDefs": [{
//             className: "Name", 
//             "targets":[0],
//             "visible": false,
//             "searchable":false
//         }]
//     });//End of create main table

  
//   $('#example tbody').on( 'click', 'tr', function () {
   
//     alert(table.row( this ).data()[0]);

// } );
});
    </script>
</head>
<body>
  
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>









<h3 class="text-center">Sri Ramakrishna Engineering College</h3>
<h3 class="text-center">Department of ECE -Library Book Details</h3>

<div class="table-responsive-sm" >
<table id="example" class="table table-striped table-bordered" style = "overflow-x:auto;" cellspacing="0" width="100%">
       
<thead>
            <tr>
            <th>Book Name</th>
            <th>Authors</th>
            <th>publisher</th>
            <th>Access No</th>
            <th>Book No</th>
            
            <th>Bero No</th> 
                        <th>Shelf No</th>
            <th>availability</th>
            </tr>
        </thead>
 
        <tfoot>
            <tr>
            <th>Book Name</th>
            <th>Authors</th>
            <th>publisher</th>
            <th>Access No</th>
            <th>Book No</th>
            
            <th>Bero No</th>  
            <th>Shelf No</th>
            <th>availability</th>
            </tr>
        </tfoot>
 
        <tbody>
            
                <!-- <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td> -->






                <?php include 'open/LoginContents/assets/connection.php';?>


<?php

// $query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,s.RegisterNo_EmpCode as RegNo,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId
// FROM departmentlibrarybookdetails d 
// JOIN issueDetailsBook i ON i.book_id= d.id
// JOIN studentdetails s on i.stud_id = s.id";
$query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.Authors as authors, d.BeroNo,d.ShelfNo, d.Publisher as publisher, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId
FROM departmentlibrarybookdetails d 
left JOIN  issuedetailsbook i  ON i.book_id= d.id
left JOIN studentdetails s on i.stud_id = s.id";




//$query = "select * from departmentlibrarybookdetails where AccessNo = '$BookAccessNum' and BookNo = $BookNum"; 
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {
  echo '<tr>';
  echo '<td>'.$row['BookName'].'</td>';

    echo '<td>'.$row['authors'].'</td>';
    echo '<td>'.$row['publisher'].'</td>';
    echo '<td>'.$row['accessNo'].'</td>';
    echo '<td>'.$row['bookNo'].'</td>';
    echo '<td>'.$row['BeroNo'].'</td>'; //            <th>Shelf No</th>
    echo '<td>'.$row['ShelfNo'].'</td>'; 
    if(isset($row['returnDate']) && isset($row['issueDate']) ){
        echo '<td>available</td>';

    }
    
    elseif(isset($row['issueDate']) &&  is_null($row['returnDate']) ){ //StudentCode
        if ($row['RegOrEmpNum']==1){
            $whois = "Student ";
        }else{
            $whois = "Faculty ";

        }
      echo '<td>not available taken by  '.$whois.$row['Name'].' - ('.$row['RegOrEmpNum'].')'.' </td>'; 
    }
else{
  echo '<td>available</td>';
}
echo '</tr>';
}

?>











            
            
        </tbody>
    </table>
    </div>
</body>



</html>

About this Page: <br>Created as a Student Project done by : Prajith K(2002144), Gokul M(2002064), Arun Kumar S(2002018), Amal Megha John(2002010)<br> Supported by Boomiha S(2202030), Abinaya S(2202004), Dharshini C(2202043), Darsina M(2202036), Desigashri M(2202037)<br>
 Guided by A. Vijay [AP/Sr.G], Department of ECE. <!-- <p><a href="mailto:hege@example.com">hege@example.com</a></p> -->



