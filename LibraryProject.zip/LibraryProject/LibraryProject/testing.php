<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table with Header and Footer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px;
        }

        table, th, td {
            border: 1px solid #333;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #333;
            color: #fff;
        }

    </style>
</head>
<body>
    <header>
        <h1>Page Header</h1>
    </header>

    <table>
        <thead>
            <tr>
                <th>Header 1</th>
                <th>Header 2</th>
                <th>Header 3</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Data 1</td>
                <td>Data 2</td>
                <td>Data 3</td>
            </tr>
            <tr>
                <td>Data 4</td>
                <td>Data 5</td>
                <td>Data 6</td>
            </tr>
        </tbody>
    </table>

    <footer>
   
  <br>
  <br>
  <br>
  <br>
  <p>This webpage is created as a Student Project done by : Prajith K(2002144), Gokul M(2002064), Arun Kumar S(2002018), Amal Megha John(2002010)<br> supported by Boomiha S(2202030), Abinaya S(2202004), Dharshini C(2202043), Darsina M(2202036), Desigashri M(2202037) </p>
 This web project is guided by A. Vijay [AP/Sr.G], Department of ECE. <!-- <p><a href="mailto:hege@example.com">hege@example.com</a></p> -->

        <p>Page Footer</p>
    </footer>
</body>
</html>
