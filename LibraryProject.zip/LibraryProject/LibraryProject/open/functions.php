<?php

function First_Letter_Capital_Sentence($input)
{
    $sub_array = array();
    
$arr =  explode(" ", $input);

//print all the value which are in the array
foreach($arr as $v){
    $sub_array[] = ucfirst($v);
}
return implode(" ", $sub_array);
}

?>