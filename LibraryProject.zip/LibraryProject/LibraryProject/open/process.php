<?php
session_start();

require_once('LoginContents/assets/connection.php');
$_SESSION['User'] ="";
if (isset($_POST['Login']))
{
    if(empty($_POST['UName']) || empty($_POST['Password']))
    {
      header("location:index.php?Empty=Please Enter a valid user Name and  Password");
    }

    else
    {
      $query = "select * from username_password1 where  UserName ='".$_POST['UName']."' and BINARY Password ='".$_POST['Password']."'";
      $result = mysqli_query($con,$query);
      if($row = mysqli_fetch_array( $result)) 
      {
        //$_SESSION['User'] = $_POST['UName'];
        $_SESSION['UserId'] = $row['id'];
        $_SESSION['User'] = $row['UserName'];
        $_SESSION["loggedIn"] = true;
        //testing codes
        header("location:LoginContents/index.php");
          //echo "<td align='left' bgcolor='$bgclr'>".$row[0]."</td>";echo "</tr>";
      }   
        //end of testing codes
      
        

         
      else
      {
        header("location:index.php?Invalid= Please Enter correct USER NAME and PASSWORD");
      }
    }


}
else
 {
    echo 'not working Now';
 }
?>

<script>
$(document).ready(function(){
    var getInput = 1;
    localStorage.setItem("storageName",getInput);
});
</script>