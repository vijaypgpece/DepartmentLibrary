<!DOCTYPE html>
<html>
    
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</head>
<body>

<h3>Contact Form</h3>

<?php 

 //$_GET['issueID'];

?>
<?php include 'LoginContents/assets/connection.php';?>


<?php

$query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId,d.Authors as Authors,d.Publisher as Publisher,d.BeroNo as BeroNo,d.ShelfNo as ShelfNo
FROM issuedetailsbook i
JOIN departmentlibrarybookdetails d ON i.book_id= d.id
JOIN studentdetails s on i.stud_id = s.id
where i.id =".$_GET['issueID']."  ";






//$query = "select * from departmentlibrarybookdetails where AccessNo = '$BookAccessNum' and BookNo = $BookNum";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {

 $bookName= $row['BookName'];
 $StudentCode= $row['StudentCode'];
 $issueDate= $row['issueDate'];
 $accessNo= $row['accessNo'];
 $Name= $row['Name'];
 $RegOrEmpNum= $row['RegOrEmpNum'];
 $email= $row['email'];
 $mobNo= $row['mobNo'];
 $Authors= $row['Authors'];
 $Publisher= $row['Publisher'];
 $BeroNo= $row['BeroNo'];
 $ShelfNo= $row['ShelfNo'];
 $bookNo= $row['bookNo'];
 $issueId= $row['issueId'];

}

//echo $bookName;

// return Book 


//  $query .=$_POST["id"];
$query= "update issuedetailsbook SET return_date_time = now() where id =".$_GET['issueID']."  ";

if(mysqli_query($connect, $query))
 {
  echo 'Data Updated';
 }
 else {
     echo $_POST["id"];
 }




?>









<div class="container">
  <form >
    <label for="fname">Name of the student/Faculty: </label>
    <input type="text" id="fname" name="firstname" placeholder="<?php echo $Name;?>"disabled>

    <label for="lname">Register No/Emp Code:</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $RegOrEmpNum ;?>" disabled>

    <label for="country">Email of the student/Faculty</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $email ;?>" disabled>
    <label for="country">mobile No of the student/Faculty</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $mobNo ;?>" disabled>
    <label for="country">Name of the Returning Book</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $bookName ;?>" disabled>
    <label for="country">Authors </label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $Authors ;?>" disabled>
    <label for="country">Publisher</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $Publisher ;?>" disabled>
    <label for="country">Issue Date & Time</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo  $issueDate ;?>" disabled>
    <label for="country">Access No</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $accessNo ;?>" disabled>
    <label for="country">Book No</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $bookNo ;?>" disabled>
    <label for="country">Bero No <Noscript></Noscript></label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $BeroNo ;?>" disabled>
    <label for="country">Shelf No</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $ShelfNo ;?>" disabled>
    <label for="country">id of the issue Book</label>
    <input type="text" id="lname" name="lastname" placeholder="<?php echo $ShelfNo ;?>" disabled>


    <div>
      <button id ="return Book"> Book Returned Successfully !! </button>
    </div>

  </form>
</div>

</body>
</html>



<script>











</script>