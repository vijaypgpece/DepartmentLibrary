<?php
session_start();
require_once('LoginContents\assets\connection.php');
$query = "insert into username_password1 ( UserName, Password) values ('".$_POST['UName']."', '".$_POST['Password']."');";
$query = "select * from username_password1 where UserName ='".$_POST['UName']."';";
      $result = mysqli_query($con,$query);
      while ($row = $result->fetch_assoc()) {
        $_POST['ExistingUserName'] = $row["UserName"];
      }



if (isset($_POST['SignUp']))
{
    if(empty($_POST['UName']) || empty($_POST['Password'])|| empty($_POST['RePassword']))
    {
      header("location:SignUp.php?Empty=Please Enter a valid user Name and  Password");
    }
    //testing codes###################################################################################
    elseif($_POST['RePassword'] != $_POST['Password'])
    {
      header("location:SignUp.php?Empty=Password is not Matching with each other");
    }
   //end of testing codes ##################################################################################
   //testing codes###################################################################################
   elseif($_POST['UName'] == $_POST['ExistingUserName'])
   {
     header("location:SignUp.php?Empty=User Name Already Exists");
   }
  //end of testing codes ##################################################################################
    else
    {
      //$query = "select * from employee where UName ='".$_POST['UName']."' and pass ='".$_POST['Password']."'";
      $query = "insert into username_password1 ( UserName, Password) values ('".$_POST['UName']."', '".$_POST['Password']."');";
 




    // upload dummy profile picture  insert
    // $imagePath = "/LoginContents/dummy.png";
    // $newPath = "/LoginContents/profilePictures/";
    // $ext = '.png';
    // $newName  = $newPath.$_POST['UName'].$ext;
    
    // $copied = copy($imagePath , $newName);
    
    
    $file = 'LoginContents/dummy.png';
    $newfile = 'LoginContents/profilePictures/'.$_POST['UName'].'.png';
    if (!copy($file, $newfile)) {
    echo "failed to copy file...\
    ";
    }
    




//       $data=("LoginContents/dummy.png");
// $imageName = "LoginContents/profilePictures/".$_POST['UName']. '.png';
// file_put_contents($imageName, $data);
     // end of dummy profile Picture insert




      $result = mysqli_query($con,$query);
      if(mysqli_fetch_array( $result)) 
      {
        header("location:LoginContents/uploadDummy.php?Empty=User Name Already Exists");
        $_SESSION['User'] = $_POST['UName'];
       // header("location:welcome.php");
       $query = "select d.Designation,f.Faculty_Name from Designation_list d join Faculty_Details f on d.ID = f.Designation_ID join Faculty_Profile_Access p on f.Faculty_ID = p.Faculty_ID join employee e on p.E_ID = e.E_ID where e.UName = '".$_POST['UName']."'";
$result = mysqli_query($con,$query);
 

    while ($row = $result->fetch_assoc()) {
        $field1name = $row["Designation"];
        $_SESSION['originalName'] = $row["Faculty_Name"];
        $_SESSION['Designation'] = $row["Designation"];
    }
    
  
   
    
if($field1name == "Class Incharge & Professor" || $field1name == "Class Incharge & Lecutrer" || $field1name == "Class Incharge & Associate Professor" || $field1name == "Class Incharge & Assistant Professor" || $field1name == "Class Incharge &  senior Lecutrer" )
{
 header("location:Faculty_Profile\Class Incharge\main-page.php"); 
 //Asign the designation value ('chairman') to the session variable chairman.
$_SESSION['Class Incharge'] = $field1name;
 echo "Class Incharge";
} 

elseif($field1name == "Professor" || $field1name == "Associate Professor" || $field1name == "Assistant Professor")
{
  header("location:Faculty_Profile\Faculty\main-page.php");  
  $_SESSION['Faculty'] = $field1name;
 // echo "Professor";
}
elseif($field1name == "Principal")
{
    header("location:Faculty_Profile\Principal\main-page.php");
    $_SESSION['Principal'] = $field1name; 
   // echo "Principal";
}

elseif($field1name == "HOD")
{
  header("location:Faculty_Profile\HOD\main-page.php");
  $_SESSION['HOD'] = $field1name;  
   // echo "HOD";
}

elseif($field1name == "Chairman")
{
$_SESSION['Chairman'] = $field1name;
header("location:Faculty_Profile\Chairman\main-page.php"); 
//Asign the designation value ('chairman') to the session variable chairman.

//echo "Chairman";
}
elseif($field1name == "Administrative staff ")
{
$_SESSION['Administrative staff'] = $field1name;
header("location:Faculty_Profile\Administrative Office Staff\main-page.php"); 
//Asign the designation value ('chairman') to the session variable chairman.

//echo "Chairman";
}
elseif($field1name == "Administrative officer")
{
$_SESSION['Administrative officer'] = $field1name;
header("location:Faculty_Profile\Administrative Office Admin\main-page.php"); 
//Asign the designation value ('chairman') to the session variable chairman.

//echo "Chairman";
}
      }
      else
      {
        header("location:index.php?Invalid= Registration Successful Login to continue");
      }
    }


}
else
 {
    echo 'not working Now';
 }
?>
