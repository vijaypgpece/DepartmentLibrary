$( document ).ready(function() {
   
    $("#LogoutBtn").click(function(){
          
      window.location.href = "Logout.php";
     
      });
  
          // function to reset the main page content to no value
          function resetMainPage() {
            document.getElementById("content").innerHTML = "";
           document.getElementById("content2").innerHTML = "";
        }
  
     $(".nav-item-side").click(function(){
      // function to remove the default style applied to the respective class of sidebar nav-item.
        $(".nav-item-side").removeAttr('style');
        // assign the style to the respective item in the sidebar that is clicked.
       $(this).css({"background-color": "#f44336", "border-radius": "7px", "box-shadow": "2px 5px 10px #111","transition": "all .3s"})
  
       
      
       // assign the selected name of the item in the page top bar heading
       var topBarHeading;
       var topBarHeading = $(this).text();
       document.getElementById("top-bar-heading").innerHTML = topBarHeading;
       // reset the mainpage content when ever a new navbar is clicked.
       resetMainPage();
      
  
      });
  // load Department Name. 
      $("#Resume-Summary").click(function(){
          
          $('#content').load("pages/entry.php");
         $('#content2').load("Resume/ResumeSummary.php");
         
          });
  
          $("#Resume-heading").click(function(){
          
           $('#content').load("pages/entry.php");
           $('#content2').load("Resume/ResumeHeader.php");
           
            });
          $("#Resume-skill-highlights").click(function(){
          
           $('#content').load("pages/entry.php");
           $('#content2').load("Resume/ResumeSkillHighlights.php");
           $('#content3').load("pages/entry.php");
            });
  
          $("#Resume-experiance").click(function(){
           $('#content').load("pages/entry.php");
           $('#content2').load("Resume/ResumeExperiance.php");
        
           
            });
          $("#addExperienceRoles").click(function(){
           $('#content').load("pages/entry.php");
           $('#content2').load("Resume/ResumeExperienceRoles.php");
           alert('selected');
        
          
           
            });
  
            $("#Resume-education").click(function(){
              $('#content').load("pages/entry.php");
              $('#content2').load("Resume/ResumeEducation.php");
              //alert('selected');
           
             
              
               });
  
            $("#Resume-Languages").click(function(){
              
              $('#content').load("pages/entry.php");
              $('#content2').load("Resume/ResumeLanguages.php");
              //alert('selected');
           
             
              
               });
  
            
               $("#oneToTen").click(function(){
              
                //$('#content').load("pages/entry.php");
                $('#resumeListDisplay').load("pages/oneToTen.php");
                //alert('selected');
             
               
                
                 });
  
                 $("#elevenToTwenty").click(function(){
              
                  //$('#content').load("pages/entry.php");
                  $('#resumeListDisplay').load("pages/elevenToTwenty.php");
                  //alert('selected');
               
                 
                  
                   });
           
            
            //########################################################
            // text count in summary
            //###########################################################
           
  
  
  
            //end of text count in summary 
   
  
  // testing codes 
     
  // end of testing codes
  
          
  });
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  