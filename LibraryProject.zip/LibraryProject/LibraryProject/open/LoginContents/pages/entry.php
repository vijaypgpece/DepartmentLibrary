<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>

  






<!-- cards -->
<section>
    <div class="container-fluid  ">
      <div class="row ">
        <div class="col-xl-10 col-lg-9 col-md-8 ml-auto ">
          <div class="row pt-md-5 mt-md-3   mb-0 ">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-6 p-2">
  
          <div class="container mt-2 ">
            <h2></h2>
            <!-- <button type="button" class="btn btn-outline-primary mr-2" id="departmentName">Department Details</button>
            <button type="button" class="btn btn-outline-primary mr-2" id="courseDetails" >Course Details</button>
            <button type="button" class="btn btn-outline-success">Student Details</button>
            <button type="button" class="btn btn-outline-info">Faculty Details</button>
            <button type="button" class="btn btn-outline-warning">Warning</button>
            <button type="button" class="btn btn-outline-danger">Danger</button>
            <button type="button" class="btn btn-outline-dark">Dark</button>
            <button type="button" class="btn btn-outline-light text-dark">Light</button> -->
          </div>
  
          <!--  -->
         






          <!--  -->
        </div>
      </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end of cards -->

</body>
</html>


<script>

$( document ).ready(function() {
  
  
  $("#departmentName").click(function(){
   
    $('#content2').load("departmentName.php");
  });

  $("#courseDetails").click(function(){
   
   $('#content2').load("courseName.php");
 });



});

</script>
