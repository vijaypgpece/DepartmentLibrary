


<ul  class="navbar-nav flex-column  ">
<li class="nav-item align-items-center" id = "Resume-profilePicture"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-user  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>1. Profile Picture </a></li>
                                <li class="nav-item align-items-center" id = "Resume-SocialNetworking"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>2. Social Networking</a></li>
                                <li class="nav-item align-items-center" id = "Resume-heading"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-info-circle  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>3. Basic Information </a></li>
                                <li class="nav-item" id = "Resume-Summary"><a href="#" class="nav-link text-white p-3 mb-2  sidebar-link nav-item-side" ><i class="fas fa-bullseye  text-light fa-lg mr-3 float-right"style="font-size:28px" ></i>4. Summary / Objective </a></li>
                                <li class="nav-item" id ="Resume-skill-highlights"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas  fa-cogs   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>5. skill highlights</a></li>
                                <li class="nav-item" id ="Resume-experiance"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-history   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>6. Experience</a></li>
                                <li class="nav-item" id ="Resume-education"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-graduation-cap text-light fa-lg mr-3 float-right" style="font-size:28px"></i>7. Education</a></li>
                                <li class="nav-item"id ="Resume-Languages"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-language text-light fa-lg mr-3 float-right" style="font-size:28px"></i>8. Languages</a></li>
 </ul>
</body> 

</html>     



 <script>
     $(document).ready(function(){
     $.getScript( "assets/script.js?v=<?php echo time(); ?>" );
     });
 </script>
