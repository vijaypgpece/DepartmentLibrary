<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>
</head>
<body>
   
   
    <div class="container-fluid ">
    <div class="row  ">
    <div class="col-xl-9 col-lg-9 col-md-8 ml-auto ">
    <div class="row  pt-md-5  mb-5 mr-5">
     <div class="col-xl-12 col-lg-12 col-md-12 col-sm-6 p-0 ">
    <div class="card shadow mb-4">
    <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
    </div>
    <div class="card-body">
<div class="table-responsive">
<!-- <div class ="container mb-3 mt-3"> -->
    <table class="table table-striped table-bordered mydatatable" style="width:100%">
         <thead>
             <tr>
                 <th>Name</th>
                 <th>Position</th>
                 <th>office</th>
                 <th>Age</th>
                 <th>start date</th>
                 <th>Salary</th>
             </tr>
         </thead>
         <tbody>
          <tr>
              <td>Karthick G</td>
              <td>Assistant Professor</td>
              <td>Ece Department</td>
              <td>33</td>
              <td>16.6.2011</td>
              <td>15,600</td>
          </tr>
          <tr>
              <td>natraj S</td>
              <td>Assistant Professor</td>
              <td>Ece Department</td>
              <td>33</td>
              <td>16.6.2011</td>
              <td>15,600</td>
          </tr>
          <tr>
              <td>J.J.Satish</td>
              <td>Assistant Professor</td>
              <td>Ece Department</td>
              <td>22</td>
              <td>16.6.2016</td>
              <td>15,600</td>
          </tr>
          <tr>
              <td>Kumar</td>
              <td>Assistant Professor</td>
              <td>Ece Department</td>
              <td>53</td>
              <td>16.6.2018</td>
              <td>15,600</td>
          </tr>
         </tbody>
         <tfoot>
         <tr>
                 <th>Name</th>
                 <th>Position</th>
                 <th>office</th>
                 <th>Age</th>
                 <th>start date</th>
                 <th>Salary</th>
             </tr>
         </tfoot>
    </table>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
    $('.mydatatable').DataTable();
</script>
</body>
</html>