



<ul  class="navbar-nav flex-column  ">
                                <li class="nav-item align-items-center" id = ""><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-info-circle  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>11. Basic Information </a></li>
                                <li class="nav-item" id = ""><a href="#" class="nav-link text-white p-3 mb-2  sidebar-link nav-item-side" ><i class="fas fa-bullseye  text-light fa-lg mr-3 float-right"style="font-size:28px" ></i>12. Summary / Objective </a></li>
                                <li class="nav-item" id =""><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas  fa-cogs   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>13. skill highlights</a></li>
                                <li class="nav-item" id =""><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-history   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>14. Experience</a></li>
                                <li class="nav-item" id =""><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-graduation-cap text-light fa-lg mr-3 float-right" style="font-size:28px"></i>15. Education</a></li>
                                <li class="nav-item"id =""><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-language text-light fa-lg mr-3 float-right" style="font-size:28px"></i>16. Languages</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-certificate text-light fa-lg mr-3 float-right" style="font-size:28px"></i>17. Certifications</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-desktop  text-light fa-lg mr-3 float-right" style="font-size:28px"></i>18. Software</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-music text-light fa-lg mr-3 float-right"  style="font-size:28px"></i> 19. Hobbies</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-trophy text-light fa-lg mr-3 float-right"></i>20. Achievements</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-project-diagram text-light fa-lg mr-3 float-right"></i>21. Project Profile</a></li>
                                  
 </ul>



 <script>
     $(document).ready(function(){
     $.getScript( "assets/script.js?v=<?php echo time(); ?>", function( data, textStatus, jqxhr ) {
  console.log( data ); // Data returned
  console.log( textStatus ); // Success
  console.log( jqxhr.status ); // 200
  console.log( "Load was performed." );
});
     });
 </script>