<?PHP
 session_start();
 if(isset($_SESSION['User'])){
  //header("location:../index.php");
 }
 else
  header("location:../index.php");
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="title icon" href="images/title-img.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
    <!-- <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-xymdQtn1n3lH2wcu0qhcdaOpQwyoarkgLVxC/wZ5q7h9gHtxICrpcaSUfygqZGOe" crossorigin="anonymous"></script> -->
   
     <!--    jquery   -->
<script src="https://code.jquery.com/jquery-3.5.1.js"  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>


<!--     Bootstrap css & Js -->
     <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    
    <!--    Data table js, css & bootstrap -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<!-- Croppie for Image cropping -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css">

    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="fontawesome-free-5.14.0-web/css/all.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="fontawesome-free-5.14.0-web/css/brands.css?v=<?php echo time(); ?>">

    <title>Resume Builder</title>
  </head>
  <body>
    
    <!-- navbar -->
    <nav class="navbar navbar-expand-md navbar-light ">
      <button class="navbar-toggler ml-auto mb-2 bg-light" type="button" data-toggle="collapse" data-target="#myNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="myNavbar">
        <div class="container-fluid">
          <div class="row">
            <!-- sidebar -->
            <div class="col-xl-2 col-lg-3 col-md-4 sidebar fixed-top ">
              <a href="#" class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border">ECE Department Library </a>
              <div class="bottom-border pb-3  ">

                <img src="profilePictures/<?php echo  $_SESSION['User'].".png?".time(); ?>" width="50" class="rounded mr-3" id ="profilePicture">
                <a href="#" class="text-white "><?php echo  $_SESSION['User'] ?></a>
                </div>

                  <!-- Test codes  -->
              <div class="btn-group btn-group-toggle mt-3 d-flex align-items-center" data-toggle="buttons">
  <label class="btn btn-secondary active" id="oneToTen" >
    <input type="radio" name="options" id="option1" autocomplete="off" checked>SREC- ECE Library
  </label>
  <!-- <label class="btn btn-secondary"  id="elevenToTwenty">
    <input type="radio" name="options" id="option2" autocomplete="off"> 9 - 16 
  </label>
  <label class="btn btn-secondary"  id="TwentyToThirty">
    <input type="radio" name="options" id="option3" autocomplete="off"> 17 - 24
  </label> -->
</div>
                  <!-- End of Test codes  -->
                             <!-- Test codes  -->
                  <!-- <div class = "contaner-fluid p-0">
                      <div class = "row">
                            <div class = "col-6 text-white"><button>1 - 10</button></div>
                            <div class = "col-6 text-white">11 - 20</div>
                      </div>
                  </div> -->
                            <!-- End of Test codes  -->
                        <div >
                        
 



                              <ul id ="resumeListDisplay" class="navbar-nav flex-column mt-4 ">
                                <li class="nav-item align-items-center" id = "Add-BookDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-user  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>1. Add Book Details </a></li>
                                <!-- <li class="nav-item align-items-center" id = "Add-studDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-user  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i> </a></li> -->


                                <li class="nav-item align-items-center" id = "Add-studDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>2. Add Student Details</a></li>
                                <li class="nav-item align-items-center" id = "Add-facultyDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>3. Add Faculty Details</a></li>
                                <li class="nav-item align-items-center" id = "Add-issueBookDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>4. issue book</a></li>
                                <!-- <li class="nav-item align-items-center" id = "view-issueBookDetails"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>5. view issue book details</a></li> -->

                                <!-- <li class="nav-item align-items-center" id = "Resume-profilePicture"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-user  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>1. Profile Picture </a></li>
                                <li class="nav-item align-items-center" id = "Resume-SocialNetworking"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa fa-users  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>2. Social Networking</a></li>
                                <li class="nav-item align-items-center" id = "Resume-heading"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-info-circle  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>3. Basic Information </a></li>
                                <li class="nav-item" id = "Resume-Summary"><a href="#" class="nav-link text-white p-3 mb-2  sidebar-link nav-item-side" ><i class="fas fa-bullseye  text-light fa-lg mr-3 float-right"style="font-size:28px" ></i>4. Summary / Objective </a></li>
                                <li class="nav-item" id ="Resume-skill-highlights"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas  fa-cogs   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>5. skill highlights</a></li>
                                <li class="nav-item" id ="Resume-experiance"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-history   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>6. Experience</a></li>
                                <li class="nav-item" id ="Resume-education"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-graduation-cap text-light fa-lg mr-3 float-right" style="font-size:28px"></i>7. Education</a></li>
                                <li class="nav-item"id ="Resume-Languages"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-language text-light fa-lg mr-3 float-right" style="font-size:28px"></i>8. Languages</a></li>
                                <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-certificate text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Certifications</a></li> -->
                                <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-desktop  text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Software</a></li> -->
                                <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-music text-light fa-lg mr-3 float-right"  style="font-size:28px"></i> 10. Hobbies</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-trophy text-light fa-lg mr-3 float-right"></i>11. Achievements</a></li>
                                <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-project-diagram text-light fa-lg mr-3 float-right"></i>12. Project Profile</a></li> --> -->
                                  
                                                                                                                                
                              </ul>

                              <ul id ="resumeListDisplay1" class="navbar-nav flex-column mt-4 ">
                              
                              <li class="nav-item align-items-center" id = "Resume-certification"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-certificate text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>9. Certification </a></li>
                              <li class="nav-item align-items-center" id = "Resume-Software"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-desktop  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>10. Softwares & Programming languages</a></li>
                              <li class="nav-item align-items-center" id = "Resume-hobbies"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="	fas fa-table-tennis text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>11. Hobbies </a></li>
                              <li class="nav-item" id = "Resume-Summary"><a href="#" class="nav-link text-white p-3 mb-2  sidebar-link nav-item-side" ><i class="	fas fa-book-open  text-light fa-lg mr-3 float-right"style="font-size:28px" ></i>12. Publications </a></li>
                              <li class="nav-item" id ="Resume-skill-highlights"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-handshake   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>13. Self-Development Programmes</a></li>
                              <li class="nav-item" id ="Resume-experiance"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-hand-pointer   text-light fa-lg mr-3 float-right" style="font-size:28px"></i>14. Membership</a></li>
                              <li class="nav-item" id ="Resume-education"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-chalkboard-teacher text-light fa-lg mr-3 float-right" style="font-size:28px"></i>15. Short Term / Online Courses</a></li>
                              <li class="nav-item"id ="Resume-Languages"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-award text-light fa-lg mr-3 float-right" style="font-size:28px"></i>16. Awards</a></li>
                              <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-certificate text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Certifications</a></li> -->
                              <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-desktop  text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Software</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-music text-light fa-lg mr-3 float-right"  style="font-size:28px"></i> 10. Hobbies</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-trophy text-light fa-lg mr-3 float-right"></i>11. Achievements</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-project-diagram text-light fa-lg mr-3 float-right"></i>12. Project Profile</a></li> -->
                                
                                                                                                                              
                            </ul>


                            <ul id ="resumeListDisplay2" class="navbar-nav flex-column mt-4 ">
                              
                              <li class="nav-item align-items-center" id = "Resume-profilePicture"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-project-diagram  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>17. Projects </a></li>
                              <li class="nav-item align-items-center" id = "Resume-SocialNetworking"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-address-book  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>18. Personal Information</a></li>
                              <li class="nav-item align-items-center" id = "Resume-heading"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side" ><i class="fas fa-comment  text-light fa-lg mr-3 mb-2  float-right" style="font-size:28px"></i>19. Reference </a></li>
                              <li class="nav-item" id = "Resume-Summary"><a href="#" class="nav-link text-white p-3 mb-2  sidebar-link nav-item-side" ><i class="fas fa-user-check  text-light fa-lg mr-3 float-right"style="font-size:28px" ></i>20. Declaration </a></li>
      
                              
                              <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-certificate text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Certifications</a></li> -->
                              <!-- <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-desktop  text-light fa-lg mr-3 float-right" style="font-size:28px"></i>9. Software</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-music text-light fa-lg mr-3 float-right"  style="font-size:28px"></i> 10. Hobbies</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-trophy text-light fa-lg mr-3 float-right"></i>11. Achievements</a></li>
                              <li class="nav-item"><a href="#" class="nav-link text-white p-3 mb-2 sidebar-link nav-item-side"><i class="fas fa-project-diagram text-light fa-lg mr-3 float-right"></i>12. Project Profile</a></li> -->
                                
                                                                                                                              
                            </ul>

                         </div>
            </div>
            <!-- end of sidebar -->

            <!-- top-nav -->
            <div class="col-xl-10 col-lg-9 col-md-8 ml-auto bg-dark fixed-top py-2 top-navbar">
              <div class="row align-items-center">
                <div class="col-md-4">
                  <h4 class="text-light text-uppercase mb-0" id ="top-bar-heading">Dashboard</h4>
                </div>
                <div class="col-md-5">
                  <form>
                    <div class="input-group">
                      <input type="text" class="form-control search-input" placeholder="Search...">
                      <button type="button" class="btn btn-white search-button"><i class="fas fa-search text-danger"></i></button>
                    </div>
                  </form>
                </div>
                <div class="col-md-3">
                  <ul class="navbar-nav">
                    <li class="nav-item icon-parent"><a href="#" class="nav-link icon-bullet"><i class="fas fa-comments text-muted fa-lg"></i></a></li>
                    <li class="nav-item icon-parent"><a href="#" class="nav-link icon-bullet"><i class="fas fa-bell text-muted fa-lg"></i></a></li>
                    <li class="nav-item ml-md-auto"><a href="#" class="nav-link" data-toggle="modal" data-target="#sign-out"><i class="fas fa-sign-out-alt text-danger fa-lg"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- end of top-nav -->
          </div>
        </div>
      </div>
    </nav>
    <!-- end of navbar -->

    <!-- modal -->
    <div class="modal fade" id="sign-out">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Want to leave?</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            Press logout to leave
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">Stay Here</button>
            <button type="button" class="btn btn-danger"  id="LogoutBtn" data-dismiss="modal">Logout</button>
          </div>
        </div>
      </div>
    </div>
    <!-- end of modal -->

    



    <div  id ="content">
  <div class="card-body">Basic card</div>
</div>

  







<div  class ="col-xl-10 col-lg-8 col-md-6 col-sm-3 ml-auto p-3" id ="content2">


</div>

<div  class ="col-xl-10 col-lg-8 col-md-6 col-sm-3 ml-auto p-3" id ="content3">


</div>





    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
    <script src="assets/script.js?v=<?php echo time(); ?>"></script>
    <script src="fontawesome-free-5.14.0-web/js/all.js?v=<?php echo time(); ?>"></script>
    <script src="fontawesome-free-5.14.0-web/js/brands.js?v=<?php echo time(); ?>"></script>
    <!-- bootbox code -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.0/bootbox.min.js"></script>




    
  </body>









</html>



<script> 
$(document).ready(function(){


setInterval(function(){
var testUpload = localStorage.getItem("storageName");
if (testUpload == 1){
//$("#profilePicture").load(window.location.href + " #here" );
      d = new Date();
      $("#profilePicture").attr("src", "profilePictures/<?php echo  $_SESSION['User'].".png"; ?>?"+d.getTime());
      var getInput = 0;
      localStorage.setItem("storageName",getInput);
}
      
}, 3000);
});
</script>



