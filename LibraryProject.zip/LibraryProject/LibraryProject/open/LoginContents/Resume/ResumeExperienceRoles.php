<html>

 <head>
  <title>Experiance</title>

  
 </head>


 <div class="card shadow mb-4">
 
  <div class="card-header py-2 ">
  
    <h6 class="m-0 font-weight-bold text-primary ">Roles and Responsibilities Table:</h6>
    

   
    </div>
  
  <div class="card-body ">
    <div class="table-responsive ">
      <table class="table display table-bordered" id="dataTable"  cellspacing="0">
        <thead>


        <div align="left" class="m-0">
        <button type="button" name="add" id="addResumeExperienceDetails" class="btn btn-primary btn-xs "><i class="fa fa-plus" aria-hidden="true"></i> Add Roles and Responsibilities Details</button>
        <button type="button" name="add" id="GoBackToExperiance" class="btn btn-secondary btn-xs ml-2"><i class="fa fa-table" aria-hidden="true"></i> Experience Details Table </button>
        <a href="pdf/ResumeTemplate01.php" class=" d-sm-inline-block btn btn-sm btn-primary shadow-sm float-right" target="_blank"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>

     <!--<button type="button" name="add" id="add" class="btn btn-info">Add</button> -->
    </div>
 <body>
  <div class="container box ">
  
   
   <div class="table-responsive">
  
 
    
    <div id="alert_message">  </div>
    <table id="user_data3" class="table table-bordered table-striped display">
     <thead>
      <tr>
        <th>Company Name</th>
       <th>Roles and Responsibilities</th>
      <th>Delete</th>
      
      </tr>
     </thead>
    </table>
   </div>
  </div>

 


<!-- test form model display -->
  <div id="ResumeHeaderModal" class="modal fade ">
    	<div class="modal-dialog ">
    		<form method="post" id="employeeForm">
    			<div class="modal-content ">
    				<div class="modal-header">
    					
						<h4 class="modal-title " id ="ResumeHeader"><i class="fa fa-plus"></i> Edit User</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
    				</div>
    				<div class="modal-body">
  						<div class="form-group">
							<label for="name" class="control-label ">Company Name</label>
              <!-- Displaying Company Name and obaining Company id for combining table to create normal form -->
              <select class="form-control" id="Company_id" name="Company_id">
              <!-- PHP codes to get list -->
              <?php include '../assets/connection.php';?>
              <?php
              session_start();
              $query = "SELECT * FROM resume_experience1  ";
              
              $result = mysqli_query($connect, $query);
              
             
              while($row = mysqli_fetch_array($result)) {
                if ($row["Profile_ID"]==$_SESSION['UserId']){
                  echo '<option value="'.$row["id"].'">'.$row["Company_Name"].'</option>';
                }
              }
                ?>
                </select>
                <!-- end of PHP codes to get list -->
                <label for="name" class="control-label mt-2 ">Roles and Responsibilities</label>
                <label for="name" class="control-label mt-2 ">(Add one by one)</label>
              <textarea rows="12" class="form-control " cols="50" id="Summary1" name="Summary" form="ResumeSummary" placeholder ="Enter and add your roles one at a time"></textarea>	
              <label for="name" class="control-label  " id = "textCountSummary1">Remaining Letters : 150</label>

							
						</div>
            <!--
						<div class="form-group">
							<label for="age" class="control-label">Age</label>							
							<input type="number" class="form-control" id="empAge" name="empAge" placeholder="Age">							
						</div>	   	
						<div class="form-group">
							<label for="lastname" class="control-label">Last Name</label>							
							<input type="text" class="form-control"  id="last_name" name="last_name" placeholder="Parent Name/Family Name" required>							
						</div>	 
						<div class="form-group">
							<label for="address" class="control-label">Address</label>							
							<textarea class="form-control" rows="5" id="address" name="address"></textarea>							
						</div>
						<div class="form-group">
							<label for="lastname" class="control-label">Designation</label>							
							<input type="text" class="form-control" id="designation" name="designation" placeholder="Designation">			
						</div>						
    				</div>
            -->
    				<div class="modal-footer">
    					<input type="hidden" name="empId" id="empId" />
    					<input type="hidden" name="action" id="action" value="" />
    					<input type="submit" name="ResumeRoleSave" id="ResumeRoleSave" class="btn btn-info" value="ResumeRoleSave" />
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		</form>
    	</div>
    </div>



<!-- test form end of model display -->





 </body>
</html>






<script type="text/javascript" language="javascript" >
 $(document).ready(function(){

 
  document.getElementById('Summary1').addEventListener('keydown', function (event) {

setInterval(function(){
var str1 = "Remaining Letters: ";
//var str2 = i -= 1;
 var str3  = $('#Summary1').val();
var str2 = 150-str3.length;
var res = str1.concat(str2);
var res1 = str3.substr(0, 150);
$("#textCountSummary1").text(res);
if(str3.length===0){
  $("#textCountSummary1").text('Remaining Letters : 150');
}
if(str2<0){
 // alert('value exceeds the maximum count');
 //$("#textCountSummary1").text('Remaining Letters : Maximum Count reached');
  //bootbox.alert("Summary text limit exceeded!");
  document.getElementById('Summary1').value = res1;
}
}, 300);
  
});



// test model form 

// on clicking "Add Employee" button
  $('#addResumeExperienceDetails').click(function(){
    
   
    //testing codes
     
      $('#ResumeHeaderModal').modal('show');
		$('#employeeForm')[0].reset();
		$('#ResumeHeader').html("<i class='fa fa-plus'></i> Add Roles and Responsibilities Details");
		$('#action').val('addResumeExperienceDetails');
		$('#ResumeRoleSave').val('Add');
   
    
    // end of testing codes
    
		
  });	
  
  // on clicking "Add" button
  /*
  $("#employeeModal").on('submit','#employeeForm', function(event){
    alert("save clicked")
		event.preventDefault();
		$('#save').attr('disabled','disabled');
		var formData = $(this).serialize();
		$.ajax({
			url:"formTesting/action.php",
			method:"POST",
			data:formData,
			success:function(data){		
        alert(data);		
				$('#employeeForm')[0].reset();
				$('#employeeModal').modal('hide');				
				$('#save').attr('disabled', false);
        //employeeData.ajax.reload();
        

      }
      
		})
  });		

  */


  $(document).on('click', '#ResumeRoleSave', function(){
   
    event.preventDefault();
    //$('#save').attr('disabled','disabled');
   var Company_id = document.getElementById("Company_id").value;//$('#first_name').text();
   var roles_and_responsibilities = document.getElementById("Summary1").value;//$('#first_name').text();
  //  var Address = document.getElementById("Address").value;//$('#first_name').text();
  //  var Phone_no = document.getElementById("Phone_no").value;//$('#first_name').text();
  //  var Email = document.getElementById("Email").value;//$('#first_name').text();
  //  var vehicle1 = document.getElementById("vehicle1").value;//$('#first_name').text();
  //  //var last_name = document.getElementById("last_name").value;
  // alert(Department_name);
   if((Company_id != '' )&&(roles_and_responsibilities!=""))
   {
    $.ajax({
     url:"Table/Experience/insertRoles.php",
     method:"POST",
     data:{Company_id:Company_id,
      roles_and_responsibilities:roles_and_responsibilities
       
                                 },
     success:function(data)
      {
       //alert(data);
      $('#ResumeHeaderModal').modal('hide');
      $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
      
      $('#user_data3').DataTable().destroy();
      fetch_data();
     }
    });
    setInterval(function(){
     $('#alert_message').html('');
    }, 5000);
   }
   else
   {
    bootbox.alert("Role/Responsibility field is unfield.");
   }
  });










  
  // end of test model form 

  //fetch_data function call 
 
 fetch_data();
 

 // test codes 
/*
 $("#user_data2").dataTable({
        aaSorting: [[2, 'asc']],
        bPaginate: false,
        bFilter: false,
        bInfo: false,
        bSortable: true,
        bRetrieve: true,
        aoColumnDefs: [
            { "aTargets": [ 0 ], "bSortable": true },
            { "aTargets": [ 1 ], "bSortable": true },
            { "aTargets": [ 2 ], "bSortable": true },
            { "aTargets": [ 3 ], "bSortable": false },
            { "aTargets": [ 4 ], "bSortable": false },
            { "aTargets": [ 5 ], "bSortable": false },
            { "aTargets": [ 6 ], "bSortable": false }
          ],
          "ajax" : {
     url:"Table/fetch.php?v= <?php //echo time(); ?>",
     type:"POST"
    }
   });
    //}); 
*/

 //end of test codes 


//fetch_data function declare to get data from database and to display in table format using dataTable library.
  function fetch_data()
  {
   
   var dataTable = $('#user_data3').DataTable({
    "retrieve": true,
    "processing" : true,
    "searching": false,
    "info": false,
    "paging": false,
    "serverSide" : true,
    "order" : [],
     "aoColumns": [
      { "bSortable": false },
{ "bSortable": false },
{ "bSortable": false }
] , 
    "ajax" : {
     url:"Table/Experience/fetchsRoles.php?v=<?php echo time(); ?>",
     type:"POST"
    }
   });
  }
  
  //declaring update_data function to update in the database when values are edited in their respective place.
  
  function update_data(id, column_name, value)
  {
   $.ajax({
    url:"Table/Experience/updateRoles.php",
    method:"POST",
    data:{id:id, column_name:column_name, value:value},
    success:function(data)
    {
     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
     $('#user_data3').DataTable().destroy();
     //fetch_data();
     
    }
   });
   setInterval(function(){
    $('#alert_message').html('');
   }, 5000);
  }
// calling Update_data function when the document got blur.
  $(document).on('blur', '.update', function(){
   var id = $(this).data("id");
   var column_name = $(this).data("column");
   var value = $(this).text();
   update_data(id, column_name, value);
   
  });


  
  // $('#add').click(function(){
  //  var html = '<tr>';
  //  html += '<td contenteditable id="data1"></td>';
  //  html += '<td contenteditable id="data2"></td>';
  //  html += '<td><button type="button" name="insert" id="insert" class="btn btn-success btn-xs">Insert</button></td>';
  //  html += '</tr>';
  //  $('#user_data tbody').prepend(html);
  // });
  
  // $(document).on('click', '#insert', function(){
  //  var first_name = $('#first_name').text();
  //  var last_name = $('#last_name').text();
  //  if(first_name != '' && last_name != '')
  //  {
  //   $.ajax({
  //    url:"Table/insert.php",
  //    method:"POST",
  //    data:{first_name:first_name, last_name:last_name},
  //    success:function(data)
  //    {
  //     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
  //     $('#user_data').DataTable().destroy();
  //     fetch_data();
  //    }
  //   });
  //   setInterval(function(){
  //    $('#alert_message').html('');
  //   }, 5000);
  //  }
  //  else
  //  {
  //   alert("Both Fields is required");
  //  }
  // });
  
  // $(document).on('click', '.deptDelete', function(){
  //  var Department_ID = $(this).attr("Department_ID");
  //  if(confirm("Are you sure you want to remove this?"))
  //  {
  //   $.ajax({
  //    url:"Table/delete.php",
  //    method:"POST",
  //    data:{Department_ID:Department_ID},
  //    success:function(data){
  //     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
  //     $('#user_data').DataTable().destroy();
  //     fetch_data();
  //    }
  //   });
  //   setInterval(function(){
  //    $('#alert_message').html('');
  //   }, 5000);
  //  }
  // });
 });





</script>

<script>
//         $(document).on("click", ".deptDelete", function(e) {
//           e.preventDefault();

//           var Department_ID = $(this).attr("Department_ID");

//           var str1 = "are you sure to delete the department Name corresponding to department ID ";
//          var str2 = Department_ID;
//           var res = str1.concat(str2);

//            bootbox.confirm(res, function(result){
//      cosole.log("hello");
// });



// e.preventDefault();// used to stop its default behaviour 
//              bootbox.confirm(Are you sure you want to delete ? , function (confirmed) {
//                  if (confirmed == true) {
//                   // place here what we want to do
//                      __doPostBack('btnDelete', 'OnClick');
//                  } 
//                   else 
//                   {

//                    }
//              });


          
//         });

</script>
        
    <script>
$(document).on("click", ".rolesDelete", function(e) {
  var id = $(this).attr("id");
  
    // redeclaring the fetch_data function inside the bootbox as it is not working.
  function fetch_data()
{
  table.destroy();
 var dataTable = $('#user_data3').DataTable({
  "retrieve": true,
  "processing" : true,
  "serverSide" : true,
  "order" : [],
   "aoColumns": [
    { "bSortable": false },
    { "bSortable": false },
{ "bSortable": false }
] , 
  "ajax" : {
   url:"Table/Experience/fetchsRoles.php?v=<?php echo time(); ?>",
   type:"POST"
  }
 });
}

// using bootbox to show model instead of alert box.
//var res = "Are you sure to delete this Experience Record ? ";
// var str2 = Company_Name; 
// var str3 = " ?"; 
// var str4 = str1.concat(str2);
// var res = str4.concat(str3);

           // bootbox.confirm(res, function(data) {
               // if (data == true) {
                  $.ajax({
     url:"Table/Experience/deleteRoles.php",
     method:"POST",
     data:{id:id},
     success:function(data){
      $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
      $('#user_data3').DataTable().destroy();
      $('#content').load("pages/entry.php");
      $('#content2').load("Resume/ResumeExperienceRoles.php");

  fetch_data();
      
     }
     
    });
    setInterval(function(){
     $('#alert_message').html('');
     
    }, 5000);
               // }
               // else{
               //   console.log("rejected");
               // }
          //  });
        });
        $(document).ready(function(){

        $("#GoBackToExperiance").click(function(){
         $('#content').load("pages/entry.php");
         $('#content2').load("Resume/ResumeExperiance.php");
         
      
         
          });
        });  
         
         
    </script>
