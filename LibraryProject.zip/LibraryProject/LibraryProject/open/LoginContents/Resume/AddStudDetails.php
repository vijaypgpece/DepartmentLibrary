<html>

 <head>
  <title>Department Name</title>

  
 </head>


 <div class="card shadow mb-4">
 
  <div class="card-header py-2 ">
  
    <h6 class="m-0 font-weight-bold text-primary ">Student Details Table:</h6>
    

   
    </div>
  
  <div class="card-body ">
    <div class="table-responsive ">
      <table class="table display table-bordered" id="dataTable"  cellspacing="0">
        <thead>


        <div align="left" class="m-0">
        <button type="button" name="add" id="addResumeBasicDetails" class="btn btn-primary btn-xs "><i class="fa fa-plus" aria-hidden="true"></i>  Add Student Details</button>
        <a href="pdf/StudentListLibrary.php" class=" d-sm-inline-block btn btn-sm btn-primary shadow-sm float-right" target="_blank"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>

     <!--<button type="button" name="add" id="add" class="btn btn-info">Add</button> -->
    </div>
 <body>
  <div class="container box ">
  
   
   <div class="table-responsive">
  
 
    
    <div id="alert_message">  </div>
    <table id="user_data" class="table table-bordered table-striped display">
     <thead>
      <tr>
      <th>S.No</th>
      <th>Register No</th>
       <th>Name</th>
       <th>Email</th>
       <th>Mobile</th>
          <th>Delete</th>

       
      </tr>
     </thead>
    </table>
   </div>
  </div>


<!-- test form model display -->
  <div id="ResumeHeaderModal" class="modal fade ">
    	<div class="modal-dialog">
    		<form method="post" id="employeeForm">
    			<div class="modal-content">
    				<div class="modal-header">
    					
						<h4 class="modal-title" id ="ResumeHeader"><i class="fa fa-plus"></i> Edit User</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
    				</div>
    				<div class="modal-body">
  						<div class="form-group">
							<label for="name" class="control-label">Register No</label>
							<input type="number" class="form-control" id="RegNo" name="RegNo" placeholder="2002101" required>	
              <label for="name" class="control-label">Name</label>
							<input type="text" class="form-control" id="Name" name="Name" placeholder="JAYASHREE R" required>		
              <label for="name" class="control-label">Email</label>
							<input type="text" class="form-control" id="Email" name="Email" placeholder="jayashree.2002101@srec.ac.in" required>		
              
              <label for="name" class="control-label">Mobile</label>
							<input type="number" class="form-control" id="Mobile" name="Mobile" placeholder="8903674099" required>		
              
						</div>
            <!--
						<div class="form-group">
							<label for="age" class="control-label">Age</label>							
							<input type="number" class="form-control" id="empAge" name="empAge" placeholder="Age">							
						</div>	   	
						<div class="form-group">
							<label for="lastname" class="control-label">Last Name</label>							
							<input type="text" class="form-control"  id="last_name" name="last_name" placeholder="Parent Name/Family Name" required>							
						</div>	 
						<div class="form-group">
							<label for="address" class="control-label">Address</label>							
							<textarea class="form-control" rows="5" id="address" name="address"></textarea>							
						</div>
						<div class="form-group">
							<label for="lastname" class="control-label">Designation</label>							
							<input type="text" class="form-control" id="designation" name="designation" placeholder="Designation">			
						</div>						
    				</div>
            -->
    				<div class="modal-footer">
    					<input type="hidden" name="empId" id="empId" />
    					<input type="hidden" name="action" id="action" value="" />
    					<input type="submit" name="saveStudentDetails" id="saveStudentDetails" class="btn btn-info" value="saveStudentDetails" />
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		</form>
    	</div>
    </div>



<!-- test form end of model display -->





 </body>
</html>






<script type="text/javascript" language="javascript" >
 $(document).ready(function(){

 

// test model form 

// on clicking "Add Employee" button
  $('#addResumeBasicDetails').click(function(){
    
   
    //testing codes
     
      $('#ResumeHeaderModal').modal('show');
		$('#employeeForm')[0].reset();
		$('#ResumeHeader').html("<i class='fa fa-plus'></i> Add Book Details");
		$('#action').val('addResumeBasicDetails');
		$('#saveStudentDetails').val('Add');
   
    
    // end of testing codes
    
		
  });	
  
  // on clicking "Add" button
  /*
  $("#employeeModal").on('submit','#employeeForm', function(event){
    alert("save clicked")
		event.preventDefault();
		$('#save').attr('disabled','disabled');
		var formData = $(this).serialize();
		$.ajax({
			url:"formTesting/action.php",
			method:"POST",
			data:formData,
			success:function(data){		
        alert(data);		
				$('#employeeForm')[0].reset();
				$('#employeeModal').modal('hide');				
				$('#save').attr('disabled', false);
        //employeeData.ajax.reload();
        

      }
      
		})
  });		

  */


  $(document).on('click', '#saveStudentDetails', function(){
   
    event.preventDefault();
    //$('#save').attr('disabled','disabled');
   var RegNo = document.getElementById("RegNo").value;//$('#first_name').text();
   var Name = document.getElementById("Name").value;//$('#first_name').text();
   var Email = document.getElementById("Email").value;//$('#first_name').text();
   var Mobile = document.getElementById("Mobile").value;//$('#first_name').text();
 //$('#first_name').text();
   //var last_name = document.getElementById("last_name").value;
  //alert("Mobile");
   if((RegNo != '' )&&(Name!="")&&(Email!=""))
   {
    $.ajax({
     url:"Table/StudentDetails/insert.php",
     method:"POST",
     data:{RegNo:RegNo,
        Name:Name,
        Email:Email,
        Mobile:Mobile,
  
      
                                 },
     success:function(data)
      {
       //alert(data);
      $('#ResumeHeaderModal').modal('hide');
      $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
      
      $('#user_data').DataTable().destroy();
      fetch_data();
     }
    });
    setInterval(function(){
     $('#alert_message').html('');
    }, 5000);
   }
   else
   {
    bootbox.alert(Mobile);
   
   }
  });










  
  // end of test model form 

  //fetch_data function call 
 fetch_data();
 

 // test codes 
/*
 $("#user_data").dataTable({
        aaSorting: [[2, 'asc']],
        bPaginate: false,
        bFilter: false,
        bInfo: false,
        bSortable: true,
        bRetrieve: true,
        aoColumnDefs: [
            { "aTargets": [ 0 ], "bSortable": true },
            { "aTargets": [ 1 ], "bSortable": true },
            { "aTargets": [ 2 ], "bSortable": true },
            { "aTargets": [ 3 ], "bSortable": false },
            { "aTargets": [ 4 ], "bSortable": false },
            { "aTargets": [ 5 ], "bSortable": false },
            { "aTargets": [ 6 ], "bSortable": false }
          ],
          "ajax" : {
     url:"Table/fetch.php?v= <?php //echo time(); ?>",
     type:"POST"
    }
   });
    //}); 
*/

 //end of test codes 


//fetch_data function declare to get data from database and to display in table format using dataTable library.
  function fetch_data()
  {
   var dataTable = $('#user_data').DataTable({
    "processing" : true,
    "searching": true,
    "info": true,
    "paging": true,
    "serverSide" : true,
    "order" : [],
     "aoColumns": [
 { "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false }

] , 
    "ajax" : {
     url:"Table/StudentDetails/fetch.php?v=<?php echo time(); ?>",
     type:"POST"
    }
   });
  }
  
  //declaring update_data function to update in the database when values are edited in their respective place.
  
  function update_data(id, column_name, value)
  {
   $.ajax({
    url:"Table/StudentDetails/update.php ?>",
    method:"POST",
    data:{id:id, column_name:column_name, value:value},
    success:function(data)
    {
     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
     $('#user_data').DataTable().destroy();
     fetch_data();
    }
   });
   setInterval(function(){
    $('#alert_message').html('');
   }, 5000);
  }
// calling Update_data function when the document got blur.
  $(document).on('blur', '.update', function(){
   var id = $(this).data("id");
   var column_name = $(this).data("column");
   var value = $(this).text();
   update_data(id, column_name, value);
   
  });


  
  // $('#add').click(function(){
  //  var html = '<tr>';
  //  html += '<td contenteditable id="data1"></td>';
  //  html += '<td contenteditable id="data2"></td>';
  //  html += '<td><button type="button" name="insert" id="insert" class="btn btn-success btn-xs">Insert</button></td>';
  //  html += '</tr>';
  //  $('#user_data tbody').prepend(html);
  // });
  
  // $(document).on('click', '#insert', function(){
  //  var first_name = $('#first_name').text();
  //  var last_name = $('#last_name').text();
  //  if(first_name != '' && last_name != '')
  //  {
  //   $.ajax({
  //    url:"Table/insert.php",
  //    method:"POST",
  //    data:{first_name:first_name, last_name:last_name},
  //    success:function(data)
  //    {
  //     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
  //     $('#user_data').DataTable().destroy();
  //     fetch_data();
  //    }
  //   });
  //   setInterval(function(){
  //    $('#alert_message').html('');
  //   }, 5000);
  //  }
  //  else
  //  {
  //   alert("Both Fields is required");
  //  }
  // });
  
  // $(document).on('click', '.deptDelete', function(){
  //  var Department_ID = $(this).attr("Department_ID");
  //  if(confirm("Are you sure you want to remove this?"))
  //  {
  //   $.ajax({
  //    url:"Table/delete.php",
  //    method:"POST",
  //    data:{Department_ID:Department_ID},
  //    success:function(data){
  //     $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
  //     $('#user_data').DataTable().destroy();
  //     fetch_data();
  //    }
  //   });
  //   setInterval(function(){
  //    $('#alert_message').html('');
  //   }, 5000);
  //  }
  // });
 });





</script>

<script>
//         $(document).on("click", ".deptDelete", function(e) {
//           e.preventDefault();

//           var Department_ID = $(this).attr("Department_ID");

//           var str1 = "are you sure to delete the department Name corresponding to department ID ";
//          var str2 = Department_ID;
//           var res = str1.concat(str2);

//            bootbox.confirm(res, function(result){
//      cosole.log("hello");
// });



// e.preventDefault();// used to stop its default behaviour 
//              bootbox.confirm(Are you sure you want to delete ? , function (confirmed) {
//                  if (confirmed == true) {
//                   // place here what we want to do
//                      __doPostBack('btnDelete', 'OnClick');
//                  } 
//                   else 
//                   {

//                    }
//              });


          
//         });

</script>
        
    <script>
$(document).on("click", ".studDetailsDelete", function(e) {
  var id = $(this).attr("id");
  
    // redeclaring the fetch_data function inside the bootbox as it is not working.
    function fetch_data()
  {
   var dataTable = $('#user_data').DataTable({
    "processing" : true,
    "searching": false,
    "info": false,
    "paging": false,
    "serverSide" : true,
    "order" : [],
     "aoColumns": [
// { "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false },
{ "bSortable": false }
] , 
    "ajax" : {
     url:"Table/StudentDetails/fetch.php?v=<?php echo time(); ?>",
     type:"POST"
    }
   });
  }

// // using bootbox to show model instead of alert box.
// var str1 = " Deleting this department will lead to deletion of students and faculty details related to the department.Are you sure to delete the department with ID: ";
// var str2 = id; 
// var str3 = " ?"; 
// var str4 = str1.concat(str2);
// var res = str4.concat(str3);

           // bootbox.confirm(res, function(data) {
              //  if (data == true) {
                  $.ajax({
     url:"Table/StudentDetails/delete.php",
     method:"POST",
     data:{id:id},
     success:function(data){
      $('#alert_message').html('<div class="alert alert-success">'+data+'</div>');
      $('#user_data').DataTable().destroy();
      $('#content').load("pages/entry.php");
      $('#content2').load("Resume/AddStudDetails.php");

  fetch_data();
      
     }
     
    });
    setInterval(function(){
     $('#alert_message').html('');
     
    }, 5000);
               // }
             //   else{
             //     console.log("rejected");
             //   }
         //   });
        });
    </script>
