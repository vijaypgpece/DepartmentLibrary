<html>

 <head>
  <title>Department Name</title>

  
 </head>

<!-- Profile Picture Content  -->
 <div class="container">
          <br />
      <h3 align="center">Upload Your Resume Picture</h3>
      <br />
      <br />
			<div class="panel panel-default">
  				
  				<div class="panel-body" align="center">
  					<input type="file" name="upload_image" id="upload_image"  class ="d-flex align-items-center"/>
  					<br />
  					<div id="uploaded_image"></div>
            <img  src="profilePictures/<?php session_start(); echo  $_SESSION['User'].".png"; ?>" class="img-thumbnail  d-flex align-items-center" id ="myimg1" />
            <button type="button" class="btn btn-primary mt-3" id ="deleteProfilePicture">Delete Profile Picture</button>
  				</div>
  			</div>
  		</div>


          <div id="uploadimageModal" class="modal" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
      		<div class="modal-header">
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
        		<h4 class="modal-title ">Upload & Crop Image</h4>
      		</div>
      		<div class="modal-body">
        		<div class="row">
  					<div class="col-md-12 text-center d-flex align-items-center">
						  <div id="image_demo" style="width:450px;margin-top: 50px; height: 350px; " ></div>
  					</div>
  					<div class="col-md-12 " style="margin-left: 125px; margin-bottom: 25px;">
  						<br />
  						<br />
  						<br/>
						  <button class="btn btn-success crop_image ml-30" id ="crop_image">Crop & Upload Image</button>
					</div>
				</div>
      		</div>
      		<div class="modal-footer">
        		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      		</div>
    	</div>
    </div>
</div>



<!-- End of Profile Picture Content  -->

 



<!-- test form end of model display -->






<script>  
$(document).ready(function(){
  d = new Date();
$("#myimg1").attr("src", "profilePictures/<?php echo  $_SESSION['User'].".png"; ?>?"+d.getTime());






  

	$image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:276,
      height:354,
      type:'square' //circle
    },
    boundary:{
      width:276,
      height:354
    }
  });

  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        //console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });

  $('.crop_image').click(function(event){
    
    $image_crop.croppie('result', {
      type: 'canvas',
      size: 'viewport'
    }).then(function(response){
      $.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
      
        }
      });
      // asign a local storage variable to refresh profile picture
      var getInput = 1;
      localStorage.setItem("storageName",getInput);
    })
  });


  $('#deleteProfilePicture').click(function(event){
    
   // $image_crop.croppie('result', {
    //  type: 'canvas',
   //   size: 'viewport'
   // }).then(function(response){
      $.ajax({
        url:"deleteProfilePicture.php",
        type: "POST",
        data:{"image": '../profilePictures/vijay.png'},
        success:function(data)
        {
          $('#uploadimageModal').modal('hide');
          $('#uploaded_image').html(data);
      
        }
      });
      // asign a local storage variable to refresh profile picture
      var getInput = 1;
      localStorage.setItem("storageName",getInput);
   // })
  });







});  


</script>
