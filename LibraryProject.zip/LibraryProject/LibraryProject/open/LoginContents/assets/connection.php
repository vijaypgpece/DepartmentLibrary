<?php 
$con = mysqli_connect('localhost:3307','admin','','librarydetails');

//$con = mysqli_connect('localhost','root','','librarydetails');

$connect = $con ;
if(!$con){
    die('Please Check Your Connection'.mysqli_error());
}


//  include 'fpdf.php';
//  include 'exfpdf.php';
//  include 'easyTable.php';

//  $pdf=new exFPDF();
//  $pdf->AddPage(); 
//  $pdf->SetFont('helvetica','',10);






?>