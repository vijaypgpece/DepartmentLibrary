<?php
 include 'fpdf.php';
 include 'exfpdf.php';
 include 'easyTable.php';
 include 'compareImage.php';
 include 'changePicColor.php';
 include 'DominantPictreColor.php';
 //Start the session to get the userid.
 session_start();

 $pdf=new exFPDF();
   // to make the top margin zero.
   $pdf->AliasNbPages();
 //$pdf->SetY(500);
 $pdf->SetMargins(0,0,0);
 $pdf->AddPage(); 
 $pdf->SetAutoPageBreak(false);




 //########################################################
                    // Functions
 //########################################################

  

   
 
 
//############################################################## 
                     //Declaring Functions
//##############################################################  
 








 
//############################################################## 
                     //connecting to database and function files
//##############################################################  
 
 require_once('../assets/connection.php');
 require_once('../assets/functions.php');
 

//############################################################## 
                     //Accessing  database 
//##############################################################  



//fetching data from database
// Header details............................................................................................
$query = "select * from resume_header1 where Profile_ID =";
$query .=  $_SESSION['UserId'];
$query .=";";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {
  $First_Name = str_replace(chr(194),'',$row['First_Name']);
   //$First_Name  = $row['First_Name'];
   // test 

   // end of test 



   $Last_Name = str_replace(chr(194),"",$row['Last_Name']);
   //$Last_Name  = $row['Last_Name'];
   //converting the name to upper case.
    $Full_Name = strtoupper($First_Name." ".$Last_Name);
    
    $Address=First_Letter_Capital_Sentence($row['Address']);
    
   $Phone_no  = $row['Phone_no'];
   
   

 

   //$Phone_no = strlen('Senior Web Developer specializing in front end development. Experienced with all stages of the development cycle for dynamic web projects. Well-versed in numerous programming languages including HTML5, PHP OOP, JavaScript, CSS, MySQL. Strong background in project management and customer relations. ');
    $Email  = $row['Email'];

    if((($Phone_no==0) && ($Email !=""))||(($Phone_no!=0) && ($Email ==""))) {
      $headerRowSpan = 4;
    }else{
     $headerRowSpan = 6;
    }
   
    if(($Phone_no==0)&&($Email =="")){
      $headerRowSpan = 2;
    }

    $headerFirstElementContent = $Address;
    $headerFirstElementTitle ="Address:";
    $Phone_no_assigned = false;
    $Email_assigned = false;
       if($Address==""){
          if($Phone_no!=0){
            $headerFirstElementContent = $Phone_no;
            $headerFirstElementTitle = "Phone No:";
            $Phone_no_assigned = true;
          } else if($Email !=""){
            $headerFirstElementContent = $Email;
            $headerFirstElementTitle = "Email:";
            $Email_assigned = true;
          }
         
       }
  
    
}
// End of Header Details....................................................................................................
// Summary Details....................................................................................................
$query1 = "select * from resume_summary1 where Profile_ID =";
$query1 .=  $_SESSION['UserId'];
$query1 .=";";
$result1 = mysqli_query($con,$query1);
while ($row1 = $result1->fetch_assoc()) {

  $Summary1 = $row1['Summary'];
 // $Summary = str_replace("Â","v",$Summary1);
  $Summary = str_replace(chr(194)," ",$Summary1);
 // $Summary  = implode(" ", (explode(" ",$Summary1)));
}



// End of Summary Details....................................................................................................

//#######################################################################################################  
                     //RGB and Hex Value extraction from Profile Picture (Background Colour Select)
//#######################################################################################################   
$myImage = "../profilePictures/".$_SESSION['User']. '.png';
//$myImage = "..\profilePictures\kumar.png";
// store the image in variable 
$image = imagecreatefrompng($myImage); 
$BGprofilePicture = dominantColorImage($image);

  
// Calculate rgb pixel value at perticular point. 
$rgb = imagecolorat($image, 10, 10); 
$red = ($rgb >> 16) & 255; 
$green = ($rgb >> 8) & 255; 
$blue = $rgb & 255; 
  
//var_dump($red, $green, $blue); 

//foreground select based on background color

function getContrastColor($hexColor) 
{

        // hexColor RGB
        $R1 = hexdec(substr($hexColor, 1, 2));
        $G1 = hexdec(substr($hexColor, 3, 2));
        $B1 = hexdec(substr($hexColor, 5, 2));

        // Black RGB
        $blackColor = "#000000";
        $R2BlackColor = hexdec(substr($blackColor, 1, 2));
        $G2BlackColor = hexdec(substr($blackColor, 3, 2));
        $B2BlackColor = hexdec(substr($blackColor, 5, 2));

         // Calc contrast ratio
         $L1 = 0.2126 * pow($R1 / 255, 2.2) +
               0.7152 * pow($G1 / 255, 2.2) +
               0.0722 * pow($B1 / 255, 2.2);

        $L2 = 0.2126 * pow($R2BlackColor / 255, 2.2) +
              0.7152 * pow($G2BlackColor / 255, 2.2) +
              0.0722 * pow($B2BlackColor / 255, 2.2);

        $contrastRatio = 0;
        if ($L1 > $L2) {
            $contrastRatio = (int)(($L1 + 0.05) / ($L2 + 0.05));
        } else {
            $contrastRatio = (int)(($L2 + 0.05) / ($L1 + 0.05));
        }

        // If contrast is more than 5, return black color
        if ($contrastRatio > 5) {
            return '#000000';
        } else { 
            // if not, return white color.
            return '#FFFFFF';
        }
}



//end of foreground select based on background color

function rgb2hex($rgb) {
   $hex = "#";
   $hex .= str_pad(dechex($rgb[0]), 2, "0", STR_PAD_LEFT);
   $hex .= str_pad(dechex($rgb[1]), 2, "0", STR_PAD_LEFT);
   $hex .= str_pad(dechex($rgb[2]), 2, "0", STR_PAD_LEFT);

   return $hex; // returns the hex value including the number sign (#)
}

$rgb = array($red, $green, $blue);

 //$BGprofilePicture = rgb2hex($rgb);
 $FGprofilePicture = getContrastColor($BGprofilePicture[0]);







//##########################################################################################################  
                     //Set fonts
//########################################################################################################## 




 $pdf -> AddFont('arial-black','B','arial-black.php');
$pdf->AddFont('calibri','I','calibrii.php');
$pdf->AddFont('calibri','','calibri.php');
$pdf->AddFont('calibri','L','calibril.php');
$pdf->AddFont('calibri','B','calibrib.php');
$pdf->AddFont('calibri','BI','calibrib.php');
//##########################################################################################################  
                     //Set font size for full name next to photo to fix the entire length
//##########################################################################################################   
 $pdf->SetFont('arial-black','B',28);

$pizza  = $Full_Name;
$pieces = explode(" ", $pizza);
$tempFontSize = 28;
$cellWidth = 76.286;
for ($x = 0; $x < count($pieces); $x++) {
    $nameTemp = $pieces[$x];
    //$tempFontSize = $tempFontSize -0.1;
while ($pdf -> GetStringWidth($nameTemp)>$cellWidth){
  $tempFontSize = $tempFontSize -0.1;
  $pdf -> SetFontSize($tempFontSize);
}
  }

  $tempValue = $pdf -> GetStringWidth($nameTemp);

 //##########################################################################################################  
                     //Resume Header check for the presence of photo by comparing dummy photo with the profile photo 
//##########################################################################################################   
$class = new compareImages;
//$dummyimage = "../profilePictures/".$_SESSION['User']. '.png';
$dummyimage = '../dummy.png';
$profilePhotoStatus = $class->compare($myImage,$dummyimage);

$_SESSION["profilePhotoStatus"]=$profilePhotoStatus;

if ($profilePhotoStatus==0){
  //############################################################## 
                     //Resume Header 
//##############################################################  
        
//..........................................
$BGprofilePicture = '#000000';
$pdf -> AddFont('arial-black','B','arial-black.php');



$pdf->AddFont('calibri','I','calibrii.php');
$pdf->AddFont('calibri','','calibri.php');
$pdf->AddFont('calibri','L','calibril.php');
$pdf->AddFont('calibri','B','calibrib.php');
$pdf->AddFont('calibri','BI','calibrib.php');
//$pdf->SetFont('calibri','',10);
$pdf ->setFont('arial-black','B','15');
// $table=new easyTable($pdf, '%{15, 35, 15, 35}', 'width:350; paddingX:3;border:0; border-color:#5b9bd5; font-color:#fff; bgcolor:#5b9bd5;');
 $table=new easyTable($pdf, '{30,205,30,205,15}',' align:C; valign:M;border:1;border-color:#020202;  font-color:#fff; bgcolor:#020202; ');
// Empty space line top -- Line one empty space
$table->easyCell('', ' align:L');
//$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:0;');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  // Empty space line top -- Line two empty space
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:calibri ;line-height:0;');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();

    
 $table->easyCell('  ','rowspan:0;align:L; valign:C;font-family:arial-black;font-size:33; border-width:1; ');
 $table->easyCell($Full_Name,'rowspan:'.$headerRowSpan.';align:L; valign:T;font-family:arial-black;font-size:28; border-width:1;line-height:1; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
 if($Address==""){
  $table->easyCell('','align:L; valign:C;font-size:13;font-family:arial-black;line-height:0; ');//
 }else{
  $table->easyCell($headerFirstElementTitle,'align:L; valign:B;font-size:13;font-family:arial-black;line-height:0; ');//

 }

 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();
 //$pdf ->setFont('CALIBRI','B','15');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9; font-family:calibri ;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->easyCell($headerFirstElementContent,'align:L; valign:T;line-height:.90;paddingY:0;font-family:calibri;font-style:L ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
//   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->rowStyle(' font-size:12; paddingY:2.2; font-family:CALIBRI ;');
//  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->easyCell('helooooooooooooooooo hse she she','align:L; valign:T;line-height:0;');
//   $table->printRow();
if($Phone_no != 0 ){
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0; ');
  $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  if($Phone_no!=""){
    $table->easyCell('Phone No:','align:L; valign:B;font-family:arial-black;font-size:13; ');
  }else{
    $table->easyCell('','align:L; valign:B;font-family:arial-black;font-size:13; ');

  }
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0;line-height:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:calibri;line-height:0;border-width:0;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0;line-height:0; ');
 $table->easyCell($Phone_no ,'align:L; valign:T; line-height:0;border-width:0;font-family:calibri;font-style:L');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();

}
  

if($Email!="" ){
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0; ');
  $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  if($Email!=""){
    $table->easyCell('Email:','align:L; valign:B;font-family:arial-black;font-size:13; ');
  }else{
    $table->easyCell('','align:L; valign:B;font-family:arial-black;font-size:13; ');

  }
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0;line-height:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:calibri;line-height:0;border-width:0;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0;line-height:0; ');
 $table->easyCell($Email ,'align:L; valign:T; line-height:0;border-width:0;font-family:calibri;font-style:L');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();

}
  


   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
   $table->rowStyle(' font-size:12; paddingY:2.9; font-family:calibri ;line-height:2;');
   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
   $table->easyCell('','align:L; valign:T; ');
   $table->easyCell('','align:L; valign:T; ');
   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();


 

 
 
   $y = $pdf->GetY();
 $table->endTable(30);


} else{
  //############################################################## 
                     //Resume Header 
//##############################################################  
        
//..........................................
//img:Pics/fpdflogo.png, w100;

//$pdf->SetFont('calibri','',10);
$pdf ->setFont('arial-black','B','15');
// $table=new easyTable($pdf, '%{15, 35, 15, 35}', 'width:350; paddingX:3;border:0; border-color:#5b9bd5; font-color:#fff; bgcolor:#5b9bd5;');
 $table=new easyTable($pdf, '{100,205,15,205,15}',' align:C; valign:M;border:1;border-color: '.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].';font-color:'.$FGprofilePicture.'; ');
 //$table=new easyTable($pdf, '{100,205,15,205,15}',' align:C; valign:M;border:1;border-color: '.$ProfilePicDominantHex.';  font-color:#fff; bgcolor:'.$ProfilePicDominantHex.';font-color:'.$FGprofilePicture.'; ');
// Empty space line top -- Line one empty space
$table->easyCell('', 'align:L');
//$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:0;');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  // Empty space line top -- Line two empty space
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:calibri ;line-height:0;');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('','align:L; valign:T; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();

    
 $table->easyCell('  ',' rowspan:0;align:L; valign:C;font-family:arial-black;font-size:33; border-width:1; ');
 $table->easyCell($Full_Name,'rowspan:'.$headerRowSpan.';align:L; valign:T;font-family:arial-black;font-size:'.$tempFontSize.'; border-width:1;line-height:1; ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
 if($Address==""){
  $table->easyCell('','align:L; valign:C;font-size:13;font-family:arial-black;line-height:0; ');//
 }else{
  $table->easyCell($headerFirstElementTitle,'align:L; valign:B;font-size:13;font-family:arial-black;line-height:0; ');//

 }

 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();
 //$pdf ->setFont('CALIBRI','B','15');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9; font-family:calibri ;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->easyCell($headerFirstElementContent,'align:L; valign:T;line-height:.90;paddingY:0;font-family:calibri;font-style:L ');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
//   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->rowStyle(' font-size:12; paddingY:2.2; font-family:CALIBRI ;');
//  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->easyCell('helooooooooooooooooo hse she she','align:L; valign:T;line-height:0;');
//   $table->printRow();
if($Phone_no != 0 ){
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0; ');
  $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  if($Phone_no!=""){
    $table->easyCell('Phone No:','align:L; valign:B;font-family:arial-black;font-size:13; ');
  }else{
    $table->easyCell('','align:L; valign:B;font-family:arial-black;font-size:13; ');

  }
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0;line-height:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:calibri;line-height:0;border-width:0;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0;line-height:0; ');
 $table->easyCell($Phone_no ,'align:L; valign:T; line-height:0;border-width:0;font-family:calibri;font-style:L');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();

}
  

if($Email!="" ){
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0; ');
  $table->rowStyle(' font-size:12; paddingY:2.9;font-family:arial-black;line-height:0;');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  if($Email!=""){
    $table->easyCell('Email:','align:L; valign:B;font-family:arial-black;font-size:13; ');
  }else{
    $table->easyCell('','align:L; valign:B;font-family:arial-black;font-size:13; ');

  }
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:33; border-width:0;line-height:0; ');
 $table->rowStyle(' font-size:12; paddingY:2.9;font-family:calibri;line-height:0;border-width:0;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0;line-height:0; ');
 $table->easyCell($Email ,'align:L; valign:T; line-height:0;border-width:0;font-family:calibri;font-style:L');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();

}
  


   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
   $table->rowStyle(' font-size:12; paddingY:2.9; font-family:calibri ;line-height:2;');
   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:1; ');
   $table->easyCell('','align:L; valign:T; ');
   $table->easyCell('','align:L; valign:T; ');
   $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
   $table->printRow();


 

 
 
   $y = $pdf->GetY();
 $table->endTable(30);
//##############################################################  
     //      Resume Profile Picture 
//##############################################################  

 //$pdf->Image($myImage,6,16,27,'PNG');


}

//##############################################################  
     //      Resume Social Media link with Logo
//############################################################## 

//Generate logo with foreground color
// $FGprofilePicture  - fontcolor
$query = "SELECT * FROM `resume_social_networking` where Profile_ID = ";
$query .=  $_SESSION['UserId'];
$query .=";";
     $result = mysqli_query($con,$query);
     $profile_name = $_SESSION['User'];
     $LogoPos = 200;
     $link = $pdf->AddLink();
     $pdf->SetLink($link);
     while ($row = $result->fetch_assoc()){
      
    
$SNNameCurrent =$row['Social_Network'];
changecolorpng($profile_name, $SNNameCurrent, $FGprofilePicture);
$pdf->Image('SocialMediaLogos/user_Logos/'.$profile_name.'_'.$SNNameCurrent.'.png',$LogoPos,5,5,5,'',$row['URL']);

$LogoPos = $LogoPos -8;
    }


// $SNNameCurrent = "Twitter";



// add link and place the icons in the header with link

// $pdf->Image('SocialMediaLogos/Main_Logos/Facebook.png',200,5,5,5,'','http://www.facebook.com/kumar');
// $pdf->Image('SocialMediaLogos/user_Logos/kumar_Twitter.png',192,5,5,5,'','http://www.twitter.com/vijaypgpece');
//  $pdf->Image('SocialMediaLogos/Main_Logos/033.png',184,5,5,5,'','http://www.google.com');
// $pdf->Image('SocialMediaLogos/Main_Logos/044.png',176,5,5,5,'','http://www.google.com');
//  $pdf->Image('SocialMediaLogos/Main_Logos/055.png',168,5,5,5,'','http://www.google.com');
//  $pdf->Image('SocialMediaLogos/Main_Logos/066.png',160,5,5,5,'','http://www.google.com');
//  $pdf->Image('SocialMediaLogos/Main_Logos/githubLogo.png',152,5,5,5,'','http://www.google.com');
//  $pdf->Image('SocialMediaLogos/Main_Logos/google_scholar.png',144,5,5,5,'','https://scholar.google.com/citations?hl=en&user=I2Gh5s8AAAAJ');
// $pdf->Image('SocialMediaLogos/07.png',181,5,0,5,'','http://www.google.com');
// $pdf->Image('SocialMediaLogos/08.png',189,5,0,5,'','http://www.google.com');


//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();
 $table->rowStyle(' font-size:12; paddingY:0; font-family:calibri ;line-height:0;');
 $table->printRow();
 $table->easyCell('','align:L; valign:T; ');
 $table->printRow();
//  $table->easyCell('','align:L; valign:T; ');
//  $table->printRow();

 $y = $pdf->GetY();
 $table->endTable(30);


 

//##############################################################  
// Summary and Underline
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('Summary','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:calibri ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

  //##############################################################  
// Summary Content
//##############################################################  
  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626;  ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->rowStyle(' font-size:12; paddingY:3; font-family:calibri ;line-height:1.2;');
 $table->easyCell($Summary,'rowspan:0;align:L;border:0; valign:M;font-size:12;font-family:calibri;font-style:L ');

 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

  
//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
//  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->printRow();
//  $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:0;');
//  $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


 

//##############################################################  
// Skill Highlights  and Underline
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('Skill Highlights ','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

   
//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);
  
  //##############################################################  
//  Skill Highlights Content
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{45,20,205,20,20,205,30}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626;   ');

$query = "SELECT SkillHighlights FROM `resume_skillhighlights1` where Profile_ID = ";
$query .=  $_SESSION['UserId'];
$query .=";";
     $result = mysqli_query($con,$query);
     $sub_array = array();
     $num=0;
     while ($row = $result->fetch_assoc()){
      
      
      $sub_array[] = str_replace(chr(194)," ",$row['SkillHighlights']);
      $num++;
    }
// First Row 
$x=0;
$n=$num;
while($x < $num)
{
  if ($n==1){
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0;font-family:calibri;font-style:L;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:M;font-size:12; font-family:calibri;font-style:L');
     $x++;
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ',' rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell('','rowspan:0;align:L;border:0; valign:M;font-family:CALIBRI;font-size:12; ');
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();

  }else{
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-size:12; font-family:calibri;font-style:L');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-family:calibri;font-style:L;font-size:12; ');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();
  }
  

}


  $y = $pdf->GetY();
  $table->endTable(10);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();
 $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:0;');
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);




//##############################################################  
// Experience  and Underline
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$x = $pdf->GetX();
 $table->easyCell('Experience ','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


   //##############################################################  
// Experience company name and year Content
//##############################################################  
  //test
  
  // #################################Check for new page 

if ($y>270){
  $pdf->AddPage();
  $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
  $table->easyCell('','align:L; valign:T; ');
  $table->printRow();

   $y = $pdf->GetY()+5;
   $table->endTable(30);

   //$y = 10; 
}
 //############################################ 
  $pdf->SetY( $y);
  $pdf->SetX( 30);
  $Profile_ID=$_SESSION['UserId'];
$query = "select * from resume_experience1 where Profile_ID =";
$query .=  $_SESSION['UserId'];
$query .=" ORDER BY Worked_From DESC;";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {

  
  // #################################Check for new page 

if ($y>270){
  $pdf->AddPage();
  $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
  $table->easyCell('','align:L; valign:T; ');
  $table->printRow();

   $y = $pdf->GetY()+5;
   $table->endTable(30);

   //$y = 10; 
}
 //############################################ 



$pdf->SetY( $y);
  $time1=strtotime($row['Worked_From']);
  $month1=date("m",$time1);
  $year1=date("Y",$time1);

  $time2=strtotime($row['worked_Until']);
  $month2=date("m",$time2);
  $year2=date("Y",$time2);

  if($row['worked_Until']!='0000-00-00'){
    $work_until = $month2."/". $year2;
  }else{
    $work_until ="until now";
  }

  
  $table1=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff;  ');
  //$table1=new easyTable($pdf, 2);
  
  $Designation = str_replace(chr(194),"",$row['Designation']);
  $Company_Name = str_replace(chr(194),"",$row['Company_Name']);
  $Company_Location = str_replace(chr(194),"",$row['Company_Location']);

  $table1->rowStyle('font-size:12;font-family:calibri ;font-style:L;line-height:1.2');
  $table1->easyCell('', 'font-size:30;  font-color:#00bfff;');
  $table1->easyCell("<b>".$Designation." -</b> ".$month1."/".$year1." to ".$work_until." \n<b>". $Company_Name.", </b>".$Company_Location ."\n");
  $table1->easyCell("", 'align:R;');
  $table1->printRow(); 
  $table1->endTable(5);
  $y = ($pdf->GetY())-5;

//test codes

$Company_id = $row['id'];
$query1 = "select * from resume_experience_roles1 where Profile_ID = '$Profile_ID' and company_id_experience = ' $Company_id' ;";
 //$query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
 $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query1));
 if ($number_filter_row !=0){
  $result1 = mysqli_query($connect,$query1);
  foreach( $result1 as $data ){
  //if ($row1 = mysqli_query($connect,$query1)->fetch_assoc()) {
  
 // #################################Check for new page 

 if ($y>270){
  $pdf->AddPage();
  $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
  $table->easyCell('','align:L; valign:T; ');
  $table->printRow();

   $y = $pdf->GetY()+5;
   $table->endTable(30);

   //$y = 10; 
}
 //############################################ 

 $table=new easyTable($pdf, '{45,20,450,30}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626;   ');


  $pdf->SetY( $y);
  $roles_and_responsibilities = str_replace(chr(194),"",$data['roles_and_responsibilities']);
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12;  ');
    $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:1.2;  ');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6;  ');
     $table->easyCell($roles_and_responsibilities,'rowspan:0;align:L;border:0; valign:M;font-size:12; font-family:calibri;font-style:L; ');
      $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();
  
      $table->endTable(10);
      $y = ($pdf->GetY())-10;
  }
  $y = ($pdf->GetY()-8);
} else{
  $y = ($pdf->GetY()-5);
}
    
   // $table->endTable(10);
    
  
// }

//end of test codes
  

}
  
//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();



 $y = $pdf->GetY();
 $table->endTable(30);


 

//##############################################################  
// Education  and Underline
//##############################################################  

  // #################################Check for new page 

  if ($y>265){
    $pdf->AddPage();
    $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
    $table->easyCell('','align:L; valign:T; ');
    $table->printRow();
  
     $y = $pdf->GetY()+5;
     $table->endTable(30);
  
     //$y = 10; 
  }
   //############################################ 
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$x = $pdf->GetX();
 $table->easyCell('Education ','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y)-5;
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


 //##############################################################  
// Education Content
//##############################################################  
  //test
    // #################################Check for new page 

  if ($y>280){
    $pdf->AddPage();
    $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
    $table->easyCell('','align:L; valign:T; ');
    $table->printRow();
  
     $y = $pdf->GetY()+5;
     $table->endTable(30);
  
     //$y = 10; 
  }
   //############################################ 
  $pdf->SetY( $y)-5;
  $pdf->SetX( 30);
  $Profile_ID=$_SESSION['UserId'];
$query = "select * from resume_education1 where Profile_ID =";
$query .=  $_SESSION['UserId'];
$query .=" ORDER BY Year_of_Completion DESC;";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {

  
  // #################################Check for new page 

if ($y>280){
  $pdf->AddPage();
  $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
  $table->easyCell('','align:L; valign:T; ');
  $table->printRow();

   $y = $pdf->GetY()+5;
   $table->endTable(30);

   //$y = 10; 
}
 //############################################ 



$pdf->SetY( $y);
 
  
  $table1=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff;  ');
  //$table1=new easyTable($pdf, 2);
  
 // $Designation = str_replace(chr(194),"",$row['Designation']);
 $Degree = str_replace(chr(194),"",$row['Degree']);
  //$Company_Name = str_replace(chr(194),"",$row['Company_Name']);
  $Course = str_replace(chr(194),"",$row['Course']);
 // $Company_Location = str_replace(chr(194),"",$row['Company_Location']);
  $Year_of_Completion = str_replace(chr(194),"",$row['Year_of_Completion']);
    $University =str_replace(chr(194),"",$row['University']);
    $University_Location = str_replace(chr(194),"",$row['University_Location']);
  $table1->rowStyle('font-size:12;font-family:calibri ;font-style:L;line-height:1.2');
  $table1->easyCell('', 'font-size:30;  font-color:#00bfff;');
  $table1->easyCell("".$Degree." : <b>".$Course."</b> - ".$Year_of_Completion." \n <b>". $University."</b>, ". $University_Location ."\n");
  $table1->easyCell("", 'align:R;');
  $table1->printRow(); 



  $table1->endTable(5);
  $y = ($pdf->GetY())-5;


$y = ($pdf->GetY()-5);

}


//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y)-5;
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();



 $y = $pdf->GetY();
 $table->endTable(30);


 

//##############################################################  
// Languages  and Underline
//##############################################################  

  // #################################Check for new page 

  if ($y>265){
    $pdf->AddPage();
    $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
    $table->easyCell('','align:L; valign:T; ');
    $table->printRow();
  
     $y = $pdf->GetY()+5;
     $table->endTable(30);
  
     //$y = 10; 
  }
   //############################################ 
$pdf->SetY( $y)-5;
$query = "select * from resume_languages1 where Profile_ID =";
$query .=  $_SESSION['UserId'];
$query .=" ORDER BY CEFR DESC;";
$number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
if ($number_filter_row ==1){
  $languages = "Language";
}else{
  $languages = "Languages";
}


$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$x = $pdf->GetX();
 $table->easyCell($languages,'rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);



//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


 //##############################################################  
// Languages  Content
//##############################################################  
  //test
  $pdf->SetY( $y);
  $pdf->SetX( 30);
  $Profile_ID=$_SESSION['UserId'];
$query = "select * from resume_languages1 where Profile_ID =";
$query .=  $_SESSION['UserId'];
$query .=" ORDER BY CEFR DESC;";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {



  // #################################Check for new page 

if ($y>280){
  $pdf->AddPage();
  $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
  $table->printRow();
  $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
  $table->easyCell('','align:L; valign:T; ');
  $table->printRow();

   $y = $pdf->GetY()+5;
   $table->endTable(30);

   //$y = 10; 
}
 //############################################ 
$pdf->SetY( $y);
 
  
  $table1=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff;  ');
  //$table1=new easyTable($pdf, 2);
  
 // $Designation = str_replace(chr(194),"",$row['Designation']);
 $Languages = str_replace(chr(194),"",$row['Languages']);
  //$Company_Name = str_replace(chr(194),"",$row['Company_Name']);
  $CEFR = str_replace(chr(194),"",$row['CEFR']);
 // $Company_Location = str_replace(chr(194),"",$row['Company_Location']);
  // $Year_of_Completion = str_replace(chr(194),"",$row['Year_of_Completion']);
  //   $University =str_replace(chr(194),"",$row['University']);
  //   $University_Location = str_replace(chr(194),"",$row['University_Location']);
  $table1->rowStyle('font-size:12;font-family:calibri ;font-style:L;line-height:1.2');
  $table1->easyCell('', 'font-size:30;  font-color:#00bfff;');
  $table1->easyCell("".$Languages." - ".$CEFR);
  $table1->easyCell("", 'align:R;');
  $table1->printRow(); 
 

  $table1->endTable(5);



$y = ($pdf->GetY()-6.75);

}

$y = ($pdf->GetY()-5);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y)-5;
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();



 $y = $pdf->GetY();
 $table->endTable(30);


//##############################################################  
// Languages  and Underline
//############################################################## 

  // #################################Check for new page 

  if ($y>265){
    $pdf->AddPage();
    $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
    $table->easyCell('','align:L; valign:T; ');
    $table->printRow();
  
     $y = $pdf->GetY()+5;
     $table->endTable(30);
  
     //$y = 10; 
  }
   //############################################ 



$pdf->SetY( $y)-5;
// $query = "select * from resume_languages1 where Profile_ID =";
// $query .=  $_SESSION['UserId'];
// $query .=" ORDER BY CEFR DESC;";
// $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
// if ($number_filter_row ==1){
//   $languages = "Language";
// }else{
//   $languages = "Languages";
// }


$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$x = $pdf->GetX();
 $table->easyCell("Certification",'rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);



//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


//##############################################################  
// Certification Content
//##############################################################  
  //test
    // #################################Check for new page 

    if ($y>280){
      $pdf->AddPage();
      $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
      $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
      $table->printRow();
      $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
      $table->printRow();
      $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
      $table->easyCell('','align:L; valign:T; ');
      $table->printRow();
    
       $y = $pdf->GetY()+5;
       $table->endTable(30);
    
       //$y = 10; 
    }
     //############################################ 
    $pdf->SetY( $y)-5;
    $pdf->SetX( 30);
    $Profile_ID=$_SESSION['UserId'];
  $query = "select * from resume_certification where Profile_ID =";
  $query .=  $_SESSION['UserId'];
  $query .=" ORDER BY Issue_Date DESC;";
  $result = mysqli_query($con,$query);
  while ($row = $result->fetch_assoc()) {
  
    
    // #################################Check for new page 
  
  if ($y>280){
    $pdf->AddPage();
    $table=new easyTable($pdf, '{530}',' align:C; valign:M;border:1;border-color:'.$BGprofilePicture[0].';  font-color:#fff; bgcolor:'.$BGprofilePicture[0].'; ');
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:2; ');
    $table->printRow();
    $table->rowStyle(' font-size:12; paddingY:4; font-family:calibri ;line-height:10;');
    $table->easyCell('','align:L; valign:T; ');
    $table->printRow();
  
     $y = $pdf->GetY()+5;
     $table->endTable(30);
  
     //$y = 10; 
  }
   //############################################ 
  
  
  
  $pdf->SetY( $y);
   
    
    $table1=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff;  ');
    //$table1=new easyTable($pdf, 2);
    
   // $Designation = str_replace(chr(194),"",$row['Designation']);
   $Title = str_replace(chr(194),"",$row['Title']);
    //$Company_Name = str_replace(chr(194),"",$row['Company_Name']);
    $Description = str_replace(chr(194),"",$row['Description']);
   // $Company_Location = str_replace(chr(194),"",$row['Company_Location']);
    $Issue_Date1 = str_replace(chr(194),"",$row['Issue_Date']);
    $date = date($Issue_Date1);
    $date_arr = explode("-", $date);
    $Issue_Date = $date_arr[0]; 
    $Issued_By =str_replace(chr(194),"",$row['Issued_By']);
      
      //$University_Location = str_replace(chr(194),"",$row['University_Location']);
    $table1->rowStyle('font-size:12;font-family:calibri ;font-style:L;line-height:1.2');
    $table1->easyCell('', 'font-size:30;  font-color:#00bfff;');
    //$table1->easyCell("".$Degree.":<b>".$Course."</b> - ".$Year_of_Completion." \n <b>". $University."</b>, ". $University_Location ."\n");
    $table1->easyCell("<b>".$Title." : </b>".$Description."\n  <b>".$Issued_By."</b> - ".$Issue_Date." " ."\n");
    $table1->easyCell("", 'align:R;');
    $table1->printRow(); 
  
   
  
    $table1->endTable(5);
    $y = ($pdf->GetY())-5;
  
  
  $y = ($pdf->GetY()-5);
  
  }
  //##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();

//  $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
//  $table->printRow();
//  $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:0;');
//  $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);


 

//##############################################################  
// Softwares & Programming Languages  and Underline
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('Softwares and Programming Languages ','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

   
  //##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);
  
  //##############################################################  
//  Softwares & Programming Languages Content
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{45,20,205,20,20,205,30}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626;   ');

$query = "SELECT Software FROM `resume_software` where Profile_ID = ";
$query .=  $_SESSION['UserId'];
$query .=";";
     $result = mysqli_query($con,$query);
     $sub_array = array();
     $num=0;
     while ($row = $result->fetch_assoc()){
      
      
      $sub_array[] = str_replace(chr(194)," ",$row['Software']);
      $num++;
    }
// First Row 
$x=0;
$n=$num;
while($x < $num)
{
  if ($n==1){
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0;font-family:calibri;font-style:L;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:M;font-size:12; font-family:calibri;font-style:L');
     $x++;
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ',' rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell('','rowspan:0;align:L;border:0; valign:M;font-family:CALIBRI;font-size:12; ');
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();

  }else{
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-size:12; font-family:calibri;font-style:L');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-family:calibri;font-style:L;font-size:12; ');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();
  }
  

}


  $y = $pdf->GetY();
  $table->endTable(10);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1; font-family:CALIBRI ;line-height:0;');
$table->printRow();
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();



 $y = $pdf->GetY();
 $table->endTable(30);


//##############################################################  
// Hobbies  and Underline
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{30,475,30}',' align:C; valign:M;border:0; border-color:##262626; font-color:#262626; bgcolor:#fff; ');
// Empty space line top -- Line one empty space
$table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->easyCell('Hobbies ','rowspan:0;align:L;border:BB; valign:M;font-family:arial-black;font-size:16; border-width:0.5;border-color:#262626; ');
 $table->rowStyle(' font-size:12; paddingY:3; font-family:CALIBRI ;line-height:0;');
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
  $table->printRow();
  
  $y = $pdf->GetY();
  $table->endTable(10);

   
  //##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1.2; font-family:CALIBRI ;line-height:1;');

$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 
 $table->printRow();


 $y = $pdf->GetY();
 $table->endTable(30);
  
  //##############################################################  
//  Softwares & Programming Languages Content
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{45,20,205,20,20,205,30}',' align:C; valign:M;border:0; border-color:#262626; font-color:#262626;   ');

$query = "SELECT Hobbies FROM `resume_hobbies` where Profile_ID = ";
$query .=  $_SESSION['UserId'];
$query .=";";
     $result = mysqli_query($con,$query);
     $sub_array = array();
     $num=0;
     while ($row = $result->fetch_assoc()){
      
      
      $sub_array[] = str_replace(chr(194)," ",$row['Hobbies']);
      $num++;
    }
// First Row 
$x=0;
$n=$num;
while($x < $num)
{
  if ($n==1){
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0;font-family:calibri;font-style:L;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:M;font-size:12; font-family:calibri;font-style:L');
     $x++;
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ',' rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell('','rowspan:0;align:L;border:0; valign:M;font-family:CALIBRI;font-size:12; ');
     
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();

  }else{
    $table->easyCell(' ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');

    $table->rowStyle(' font-size:12; paddingY:0; font-family:CALIBRI ;line-height:1.2;');
    $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-size:12; font-family:calibri;font-style:L');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
     $table->easyCell(' ','img:dot.png,w1.5; rowspan:0;align:C; valign:T;font-family:CALIBRI;font-size:10; border-width:0;paddingY:1.6; ');
     $table->easyCell($sub_array[$x],'rowspan:0;align:L;border:0; valign:T;font-family:calibri;font-style:L;font-size:12; ');
     $x++;
     $n--;
     $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
      $table->printRow();
  }
  

}


  $y = $pdf->GetY();
  $table->endTable(10);

//##############################################################  
     //      Resume White space
//##############################################################  
$pdf->SetY( $y);
$table=new easyTable($pdf, '{450}',' align:C; valign:M;border:0; border-color:null; font-color:#fff; bgcolor:#fff; ');

// Empty space line top -- Line one empty space
$table->rowStyle(' font-size:12; paddingY:1; font-family:CALIBRI ;line-height:0;');
$table->printRow();
$table->easyCell('   ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
$table->printRow();
 $table->easyCell('  ','rowspan:0;align:L; valign:M;font-family:arial-black;font-size:12; border-width:0; ');
 $table->printRow();



 $y = $pdf->GetY();
 $table->endTable(30);






      //out put ######################################################





   

 $pdf->Output();  

?>