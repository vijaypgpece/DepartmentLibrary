<?php
 include 'fpdf.php'; //
 include 'exfpdf.php';
 include 'easyTable.php';
 require_once('../assets/connection.php');

 $pdf=new exFPDF();
 $pdf->AddPage('L'); 
 //$pdf->addPage('L');
 $pdf->SetFont('helvetica','',10);
 $_SESSION['PageFormat'] ="L";

//  $write=new easyTable($pdf, 1, 'width:50; align:C; font-style:B,U,I; font-size:15;font-family:times;');
//  $write->easyCell('Evolution of a table');
//  $write->printRow();
//  $write->endTable(5);

 //########################################################


 $tableB=new easyTable($pdf, 6, 'width:250; align:C{LC}; border:1;border-color:#fff;');

//  $tableB->easyCell("Cell 1A A\n B\n C\n D\n E\n F\n", 'rowspan:5;');
//  $tableB->easyCell("Cell 1BC BB", 'rowspan:2; colspan:2; valign:B');
//  $tableB->easyCell("Cell 1D 1");
//  $tableB->easyCell("New", '');
//  $tableB->printRow();
    
//  $tableB->easyCell("Cell 2D 1\n 2\n 3\n");
//  $tableB->easyCell("Cell 2D 1\n 2\n 3\n", 'rowspan:3;');
//  $tableB->printRow();
    
//  $tableB->easyCell("Cell 10 ");
//  $tableB->easyCell("Cell 12 1\n 2\n 3\n 4\n 5\n", 'rowspan:3;');
//  $tableB->easyCell("Cell 12 1\n 2\n 3\n 4\n 5\n", 'rowspan:2;');
//  $tableB->printRow();
    
//  $tableB->easyCell("Cell 12 ", '');
//  $tableB->printRow();
   
 $tableB->easyCell("",'img:Pics/logo_trust.jpg,w15;align:C;rowspan:5;valign:T');
 $tableB->easyCell("SRI RAMAKRISHNA ENGINEERING COLLEGE",'colspan:4;font-size:14;font-color:#000;font-style:B');
 $tableB->easyCell("",'img:Pics/srec-Logo.jpg,w25;align:C;rowspan:5;;valign:T');
 $tableB->printRow();


 $tableB->easyCell("[Educational Service: SNR Sons Charitable Trust] \n [Autonomous Institution, Reaccredited by NAAC with A+ Grade] \n [Approved by AICTE and Permanently Affiliated to Anna University, Chennai] \n [ISO 9001:2015 Certified and all eligible programmes Accredited by NBA] \n VATTAMALAIPALAYAM, N.G.G.O. COLONY POST,  COIMBATORE - 641 022.",'colspan:4;font-size:7;font-color:#000;align:C');

 $tableB->printRow();


 $tableB->easyCell("",'colspan:4;font-size:7;font-color:#000;align:C');

 $tableB->printRow();
 

 
 $tableB->easyCell("",'colspan:4;font-size:7;font-color:#000;align:C;rowspan:2;');

 $tableB->printRow();


 $tableB->easyCell("",'colspan:4;font-size:7;font-color:#000;align:C');

 $tableB->printRow();

 $tableB->endTable(1);






 //########################################################

 $write=new easyTable($pdf, 1, 'width:750; align:C{C}; font-style:B; font-size:15;font-family:times;');
 $write->easyCell('Department of Electronics and Communication Engineering');
 $write->printRow();
 $write->endTable(1);

 //########################################################

 $write=new easyTable($pdf, 1, 'width:750; align:C{C}; font-style:B; font-size:13;font-family:times;');
 $write->easyCell('Department Library Book Details');
 $write->printRow();
 $write->endTable(5);

 //########################################################




 $table=new easyTable($pdf, '{15, 20, 20,10,10, 150, 50,50}', 'width:300; border-color:#000; font-size:10; border:1; paddingY:2;');

 $table->rowStyle('align:{CCCCCC}; bgcolor:#ddebf7;font-style:B');
 $table->easyCell("S.No",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Acc.No",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Bero.No",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Shelf.No",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Book No",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Title of the Book",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Author",'font-size:10 ;align:C; valign:M');
 $table->easyCell("Publisher",'font-size:10 ;align:C; valign:M');
 $table->printRow();
 
 //########################################################

 $query = "select * from departmentlibrarybookdetails";
 
 $query .=" ORDER BY BookNo Asc;";
 $result = mysqli_query($con,$query);
 $Sno = 0;
 while ($row = $result->fetch_assoc()) {


   $Sno++;

 $table->printRow();
 $AccessNo = $row['AccessNo'];
 $BookNo = $row['BookNo'];
 $BeroNo = $row['BeroNo'];
 $ShelfNo = $row['ShelfNo'];
 $NameOfBook = $row['NameOfBook'];
 $Authors = $row['Authors'];
 $Publisher = $row['Publisher'];



   
    $current_y = $pdf->GetY();

    if($current_y >180) {
        // Starting page heading column for each page 
        $table->rowStyle('align:{CCCCCC}; bgcolor:#ddebf7;font-style:B');
        $table->easyCell("S.No",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Acc.No",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Bero.No",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Shelf.No",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Book No",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Title of the Book",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Author",'font-size:8 ;align:C; valign:M');
        $table->easyCell("Publisher",'font-size:8 ;align:C; valign:M');
        $table->printRow();
       }

    // content of the each page
 $table->easyCell(" $Sno", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$AccessNo", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$BookNo", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$BeroNo", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$ShelfNo", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$NameOfBook ", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$Authors", 'font-size:8 ;align:C; valign:M' );
 $table->easyCell("$Publisher", 'font-size:8 ;align:C; valign:M' );
 $table->printRow();




 //$current_y = $pdf->GetY();

  
 }
 
  $table->endTable(20);

  //#################################################################################


  $write=new easyTable($pdf, 2, 'width:750; align:C{C}; font-style:B; font-size:12;font-family:times;');
  $write->easyCell('Department Library Incharge','align:C');
  $write->easyCell('HOD/ECE','align:C');
  $write->printRow();
  $write->endTable(1);

  $filename="LibraryDetails/test.pdf";
  $pdf->Output($filename.'.pdf','F');



 $pdf->Output(); 





?>