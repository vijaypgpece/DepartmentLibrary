<?php
 $pdf->Image('../images/dina.png',10,6,30);
 $pdf->cell(275,10,'Sample College of Engineering and Technology',0,1,"C");
?>