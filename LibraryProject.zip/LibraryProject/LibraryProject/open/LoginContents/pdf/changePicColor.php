
<?php 
//#####################################################################
  //Change color of an image  using PHP 
//#####################################################################
function changecolorpng($profile_name, $SNNameCurrent, $FGprofilePicture){
  //############################## function to replace color as mentoned in the above post  ###################
// note : if we use the above post it will replace the background color with black or some other color so here is my working code.
// function ReplaceColour($img, $r1, $g1, $b1, $r2, $g2, $b2)
// {
//     if(!imageistruecolor($img))
//         imagepalettetotruecolor($img);
//     $col1 = (($r1 & 0xFF) << 16) + (($g1 & 0xFF) << 8) + ($b1 & 0xFF);
//     $col2 = (($r2 & 0xFF) << 16) + (($g2 & 0xFF) << 8) + ($b2 & 0xFF);

//     $width = imagesx($img); 
//     $height = imagesy($img);
//     for($x=0; $x < $width; $x++)
//         for($y=0; $y < $height; $y++)
//         {
//             $colrgb = imagecolorat($img, $x, $y);
//             if($col1 !== $colrgb)
//                 continue; 
//             imagesetpixel ($img, $x , $y , $col2);
//         }   
// }
//#####################################################################################


//provide the RGB value of your background here.
$rgb = array(255,255,255);
/* Your file */
// 
$file='SocialMediaLogos/Main_Logos/'.$SNNameCurrent.'.png';

/* Negative values, don't edit */
$rgb = array(255-$rgb[0],255-$rgb[1],255-$rgb[2]);

$im = imagecreatefrompng($file);




imagefilter($im, IMG_FILTER_NEGATE); 
imagefilter($im, IMG_FILTER_COLORIZE, $rgb[0], $rgb[1], $rgb[2]); 
//imagefilter($im, IMG_FILTER_COLORIZE, $rgb[0], $rgb[1], $rgb[2]); 
imagefilter($im, IMG_FILTER_NEGATE); 

imagealphablending( $im, false );
imagesavealpha( $im, true );


$hex = $FGprofilePicture;
list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");

//ReplaceColour($im, 0, 0, 0, $r, $g, $b);

//$img, $r1, $g1, $b1, $r2, $g2, $b2

$img = $im;
$r1 = 0;
$g1 = 0;
$b1 = 0;
$r2 = $r;
$g2 = $g;
$b2 = $b;

if(!imageistruecolor($img))
imagepalettetotruecolor($img);
$col1 = (($r1 & 0xFF) << 16) + (($g1 & 0xFF) << 8) + ($b1 & 0xFF);
$col2 = (($r2 & 0xFF) << 16) + (($g2 & 0xFF) << 8) + ($b2 & 0xFF);

$width = imagesx($img); 
$height = imagesy($img);
for($x=0; $x < $width; $x++)
for($y=0; $y < $height; $y++)
{
    $colrgb = imagecolorat($img, $x, $y);
    if($col1 !== $colrgb)
        continue; 
    imagesetpixel ($img, $x , $y , $col2);
}   





















$dest ='SocialMediaLogos/user_Logos/'.$profile_name.'_'.$SNNameCurrent.'.png';
imagepng($im,$dest);
//imagejpeg($im, "file.jpg");

imagedestroy($im);

}

?> 