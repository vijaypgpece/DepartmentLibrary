<?php 
//connection to database. ################################################
$con = mysqli_connect('localhost','root','','phptutorials');
$connect = $con ;
if(!$con){
    die('Please Check Your Connection'.mysqli_error());
}

//################################################# Total No of Rows ###################################################################################

$query = "SELECT COUNT(*) AS NumberOfCourses FROM course_details;";
$result = mysqli_query($con,$query);
$row = $result->fetch_assoc();
//echo "total no of rows:";
$NumberOfCourses =  $row["NumberOfCourses"];
//##########################################################################################################################################
// Span No count as per requirement ########################################################################################

$query = "SELECT * FROM course_details  ORDER BY Dept_ID,UG_PG_PhD,Course_Name ;";
$result = mysqli_query($con,$query);

$datas = array();
    if(mysqli_num_rows($result)>0){
        while ($row =mysqli_fetch_assoc($result)){
            $datas[] =$row;
        }
    }
    $deptID = array();
    foreach ($datas as $data){
        
        $deptID[]  = $data['Dept_ID'];
    }
   $tot  = mysqli_num_rows($result); 
   // echo $deptID[2],$deptID[0]."</br>"; 
   // print_r($deptID)."</br>";
    //echo "</br>".$tot."</br>" ;
      $i=1;
      $DeptIDodd = 0;
      $DeptIDeven = 0;
      $span_no = array_fill(0, $NumberOfCourses, 0);;//final array containing span with initial value of zero.
      $UniquedeptID = array();// final array containing single value and remaining as empty 
    for ($x = 0; $x < $tot ; $x++)  
    {
        
        if  ($i%2==0){
         //  echo "even - ".$deptID[$x]."</br>";
            $DeptIDeven = $deptID[$x];
            $query = "SELECT COUNT(*) AS NumberOfProducts FROM course_details where Dept_ID = $DeptIDeven  ;";
            $result = mysqli_query($con,$query);
            $row = $result->fetch_assoc();
           // echo "total no of rows:";
            $span_no[$x] =  $row["NumberOfProducts"];
        
            
           // echo "DeptIDeven - ".$DeptIDeven."</br>";
         
        } else{
        //  echo "odd - ".$deptID[$x]."</br>";
            $DeptIDodd = $deptID[$x];
  
             //assing total no of values as span to the first element
    $query = "SELECT COUNT(*) AS NumberOfProducts FROM course_details where Dept_ID = $DeptIDodd ;";
    $result = mysqli_query($con,$query);
    $row = $result->fetch_assoc();
   // echo "total no of rows:";
    $span_no[$x] =  $row["NumberOfProducts"];




        }
          if ($DeptIDodd==$DeptIDeven){
         //     echo "same"."</br>";
              $UniquedeptID[$x] = " ";
              $span_no[$x] =0;
              
          }else{
            $UniquedeptID[$x] = $deptID[$x];
            
          }
        $i++;
    }

  //  print_r($UniquedeptID)."</br>";
   // print_r($span_no)."</br>";

  //  echo $UniquedeptID[0];
   
// Span no count as per requirement ########################################################################################

//##########################################################################
// inclution of library files.

require 'fpdf.php';
include 'exfpdf.php';
include 'easyTable.php';

//##############################################################################

// Instanciation of inherited class
$pdf=new exFPDF();
$pdf->AliasNbPages();// footer function included in exfpdf class. refer to alter if needed.
$pdf->AddPage('L'); 
//$pdf->SetFont('helvetica','',10);

//########################## fonts ###########################################
// add new  google font Roboto-Bold font bold and regular

$pdf -> AddFont('Roboto-Bold','B','Roboto-Bold.php');

$pdf -> AddFont('Roboto-Medium','','Roboto-Medium.php');

//###############################################################################

// set up text color and fill color for the pages.
$pdf ->SetTextColor(0, 0, 0);
$pdf ->SetFillColor(254,222,0);


// logo and heading inclution #####################################################################
$pdf ->setFont('Roboto-Bold','B','15');
$pdf->Image('dina.png',10,6,30);
$pdf->cell(275,10,'Sample College of Engineering and Technology',0,1,"C");
$pdf->cell(275,15,'Course Details with Department ID',0,1,"C");
$pdf->cell(275,5,'',0,1,"C");
//  ###############################################################################################

// font declaraion 

$pdf ->setFont('Roboto-Bold','B','10');
// Column Heading for table #############################################################################
  // assigning the column heading for the first page seperatly as the first page contains logo and title of the content.

    $table=new easyTable($pdf, '{20, 60, 20, 26,120,25,30,50,60,45}',' align:C; valign:M;border:1; border-color:#000; ');
include('courseDetailsTableHeading.php');
//####################################################################################################################
$query = "SELECT Department_name, UG_PG_PhD, Course_ID,Course_Name, Max_Student_Strength, Course_Fee, Entered_By, Date_and_Time, Enteded_IP_Adress FROM  department_details t1 INNER JOIN course_details t2 ON t1.Department_ID = t2.Dept_ID ORDER BY Dept_ID,UG_PG_PhD,Course_Name;
";
$result = mysqli_query($con,$query);
$i=1; $j =0;
while ($row = $result->fetch_assoc()) 
  {
//#######################################################################################################################
    // assign column heading at the begining of each page. 
    
    $current_y = $pdf->GetY();
   // note : using 2 condtions to make the page heading appear in the top of each page. if you use only one condition it wont work.
   if ($current_y>170){
       
        // check if new page appears using if condition
       if($pdf->AddPage('L')) {
        include('courseDetailsTableHeading.php');
       }
       //check if the length exceeds the value of current_y axis.
       include('courseDetailsTableHeading.php');
    }
//#############################################################################################################################


if (($span_no[$j]) >0){
     $Span= $span_no[$j]*2;   
// content of a full department with 2 rows.
//$pdf ->setFont('Roboto-Bold','B','10');
$pdf ->setFont('Roboto-Medium','','9');
//First row with span content (department Name is made "rowspan" based on the course count)
$table->easyCell($i, 'align:C; valign:M; ');
$table->easyCell($row['Department_name'],'rowspan:'.$Span.';align:C; valign:M; ');
$table->easyCell($row['UG_PG_PhD'],'align:C; valign:M; ');//
$table->easyCell($row['Course_ID'],'align:C; valign:M; ');
$table->easyCell($row['Course_Name'],' align:C; valign:M; ');
$table->easyCell($row['Max_Student_Strength'],'align:C; valign:M; ');
$table->easyCell($row['Course_Fee'],'align:C; valign:M; ');
$table->easyCell($row['Entered_By'],'align:C; valign:M; ');
$table->easyCell($row['Date_and_Time'],'align:C; valign:M; ');
$table->easyCell($row['Enteded_IP_Adress'],'align:C; valign:M;');
$table->printRow();

}

else if (($span_no[$j]) ==0){
    $table->easyCell($i, 'align:C; valign:M; ');
//$table->easyCell($row['Department_name'], 'rowspan:3;align:C; valign:M; ');
$table->easyCell($row['UG_PG_PhD'],'align:C; valign:M; ');//
$table->easyCell($row['Course_ID'],'align:C; valign:M; ');
$table->easyCell($row['Course_Name'],' align:C; valign:M; ');
$table->easyCell($row['Max_Student_Strength'],'align:C; valign:M; ');
$table->easyCell($row['Course_Fee'],'align:C; valign:M; ');
$table->easyCell($row['Entered_By'],'align:C; valign:M; ');
$table->easyCell($row['Date_and_Time'],'align:C; valign:M; ');
$table->easyCell($row['Enteded_IP_Adress'],'align:C; valign:M;');
$table->printRow();


}
$j++;
$i++;
// second row excluding the department name. Note: the department name is commented below purposefully to make you clear with the concept.




// // border line at the end of each Department course list.
//  $table->rowStyle('min-height:.25;paddingY:0.02;');
//  $table->easyCell('', 'colspan:10; bgcolor:#000;');

//#############################################################################################################################
$table->printRow();







}
// end of Table 
$table->endTable(5);

// output the content as pdf file.
$pdf->Output(); 
?>




