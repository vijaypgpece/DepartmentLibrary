<?php
// $myImage = 'kumar.png';
// // //$myImage = "..\profilePictures\kumar.png";
// // // store the image in variable 
//  $image = imagecreatefrompng($myImage); 
// function rgb2hex($rgb) {
//     $hex = "#";
//     $hex .= str_pad(dechex($rgb[0]), 2, "0", STR_PAD_LEFT);
//     $hex .= str_pad(dechex($rgb[1]), 2, "0", STR_PAD_LEFT);
//     $hex .= str_pad(dechex($rgb[2]), 2, "0", STR_PAD_LEFT);
 
//     return $hex; // returns the hex value including the number sign (#)
//  }
function dominantColorImage($image){
    $sub_array = array();
for ($x = 0; $x <= 275; $x+=1) {
    for ($y = 0; $y <= 275; $y+=1) {
    $rgb = imagecolorat($image, $x, $y); 
$red = ($rgb >> 16) & 255; 
$green = ($rgb >> 8) & 255; 
$blue = $rgb & 255; 
$rgb = array($red, $green, $blue);

 
 //echo rgb2hex($rgb);
 $hex = "#";
    $hex .= str_pad(dechex($rgb[0]), 2, "0", STR_PAD_LEFT);
    $hex .= str_pad(dechex($rgb[1]), 2, "0", STR_PAD_LEFT);
    $hex .= str_pad(dechex($rgb[2]), 2, "0", STR_PAD_LEFT);



 $sub_array[] = $hex;
    }
   
  }


//  echo $sub_array[1];
//  var_dump($sub_array);



 $count=array_count_values($sub_array);//Counts the values in the array, returns associatve array
arsort($count);//Sort it from highest to lowest
$keys=array_keys($count);


//echo "The most occuring value is $keys[0][1] with $keys[0][0] occurences.";
// Calculate rgb pixel value at perticular point. 


list($r, $g, $b) = sscanf( $keys[0], "#%02x%02x%02x");
$rgb = array($keys[0],$r, $g, $b);
//echo $rgb[2];

return $rgb;

}

//  $temp =dominantColorImage($image);
//  echo $temp;
 

?>