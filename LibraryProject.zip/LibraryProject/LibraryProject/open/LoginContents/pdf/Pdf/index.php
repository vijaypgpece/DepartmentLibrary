<?php
include('fpdf17/fpdf.php');
 
 $pdf = new FPDF('p','mm','A4');
 
 $pdf ->addpage();
 
 $pdf ->setFont('Arial','B','14');
 
 $pdf->cell(130,5,'Vijay Sample Invoice',0,0);
 $pdf->cell (59,5,'Invoice',0,1); // end of line

 

  $pdf ->setFont('Arial','','12');
$pdf ->SetTextColor(167,70,141);


$pdf ->SetDrawColor(167,70,141);
 $pdf->cell(130,5,'[Street Address]',0,0);
 $pdf->cell (59,5,'',0,1); // end of line
 
 
 
 $pdf->cell(130,5,'[City,country,zip]',0,0);
 $pdf->cell (25,5,'Date',0,0);
 $pdf->cell (34,5,'[dd/mm/yyy',0,1);// end of line
 
 
 $pdf->cell(130,5,'[City,country,zip]',0,0);
 $pdf->cell (25,5,'invoice #',0,0);
 $pdf->cell (34,5,'[1234567]',0,1);// end of line
 
 $pdf->cell(130,5,'[City,country,zip]',0,0);
 $pdf->cell (25,5,'Customer ID',0,0);
 $pdf->cell (34,5,'[1234567]',0,1);// end of line
 
 
 $pdf->cell(189,20,'',0,1);//end of line
 $pdf->cell(90,5,'Bill to',0,1);//end of line
 $pdf->cell(15,5,'',0,0);
 $pdf->cell(75,5,'[Name]',0,1);//end of line
  $pdf->cell(15,5,'',0,0);
 $pdf->cell(75,5,'[Company Name]',0,1);//end of line
  $pdf->cell(15,5,'',0,0);
 $pdf->cell(75,5,'[Address]',0,1);//end of line
  $pdf->cell(15,5,'',0,0);
 $pdf->cell(75,5,'[Phone]',0,1);//end of line
   $pdf->cell(189,20,'',0,1);//end of line
    $pdf ->setFont('Arial','B','12');
	
$pdf->SetFillColor(209,207,207);	
 $pdf->cell(130,5,'Description',1,0,"L",True);
 $pdf->cell (25,5,'Taxable',1,0,"L",True);
 $pdf->cell (34,5,'Amount',1,1,"L",True);// end of line
 
     $pdf ->setFont('Arial','','12');
 $pdf->cell(130,5,'Ultracool Fridge',1,0);
 $pdf->cell (25,5,'-',1,0);
 $pdf->cell (34,5,'3250',1,1);// end of line
   $pdf->cell(130,5,'Something Else',1,0);
 $pdf->cell (25,5,'-',1,0);
 $pdf->cell (34,5,'3250',1,1);// end of line
  $pdf->cell(130,5,'Supaclean Diswasher',1,0);
 $pdf->cell (25,5,'-',1,0);
 $pdf->cell (34,5,'1200',1,1);// end of line
  $pdf->cell(130,5,'',1,0);
 $pdf->cell (25,5,'Subtotal',1,0);
 $pdf->cell (4,5,'$',1,0);
 $pdf->cell (30,5,'1200',1,1);// end of line

 $pdf->Output();
?>