<?php
//include pdf_mc_table.php, not fpdf17/fpdf.php
include('Pdf/pdf_mc_table.php');


require_once('../assets/connection.php');

// Department ID reptation stop using array by adding empty space ########################################################################################

$query = "SELECT * FROM course_details  ORDER BY Dept_ID,UG_PG_PhD,Course_Name ;";
$result = mysqli_query($con,$query);

$datas = array();
    if(mysqli_num_rows($result)>0){
        while ($row =mysqli_fetch_assoc($result)){
            $datas[] =$row;
        }
    }
    $deptID = array();
    foreach ($datas as $data){
        
        $deptID[]  = $data['Dept_ID'];
    }
   $tot  = mysqli_num_rows($result); 
   // echo $deptID[2],$deptID[0]."</br>"; 
   // print_r($deptID)."</br>";
    //echo "</br>".$tot."</br>" ;
      $i=1;
      $DeptIDodd = 0;
      $DeptIDeven = 0;
      $UniquedeptID = array();// final array containing single value and remaining as empty 
    for ($x = 0; $x < $tot ; $x++)  
    {
        
        if  ($i%2==0){
         //  echo "even - ".$deptID[$x]."</br>";
            $DeptIDeven = $deptID[$x];
            
           // echo "DeptIDeven - ".$DeptIDeven."</br>";
         
        } else{
        //  echo "odd - ".$deptID[$x]."</br>";
            $DeptIDodd = $deptID[$x];
        }
          if ($DeptIDodd==$DeptIDeven){
         //     echo "same"."</br>";
              $UniquedeptID[$x] = " ";
          }else{
            $UniquedeptID[$x] = $deptID[$x];
          }
        $i++;
    }

   // print_r($UniquedeptID)."</br>";

  //  echo $UniquedeptID[0];
   
// End of code for department ID repatation Stop #########################################################################################




//Make new object
$pdf = new PDF_MC_Table();

$pdf->AliasNbPages();
 


// add page, set font
$pdf -> AddPage('L');




// add new  google font Roboto-Bold font bold and regular

$pdf -> AddFont('Roboto-Bold','B','Roboto-Bold.php');

$pdf -> AddFont('Roboto-Medium','','Roboto-Medium.php');


//$pdf ->setFont('Arial','B','14');
$pdf ->setFont('Roboto-Bold','B','15');
 $pdf ->SetTextColor(0, 102, 102);
 $pdf ->SetFillColor(254,222,0);
 

 //$pdf->Image('../images/dina.png',10,6,30);
 //$pdf->cell(189,10,'Sample College of Engineering and Technology',0,1,"C");
 
  include('college-name-and-logo-Landscape.php');
 $pdf->cell(275,15,'Course Details with Department ID',0,1,"C");
 // end of line


 $pdf ->setFont('Roboto-Bold','B','12');
 $pdf ->SetTextColor(167,70,141);
 
 
 $pdf ->SetDrawColor(167,70,141);
  $pdf->cell(130,05,'',0,0);
  $pdf->cell (59,05,'',0,1); // end of line

 


$pdf -> SetFont('Roboto-Medium','',12);
$pdf ->SetTextColor(167,70,141);
$pdf ->SetDrawColor(167,70,141);


// Set width for each column (11 columns) -Note:10 columns  is working and not 11 columns
$pdf->SetWidths(Array(10,15,10,15,60,15,20,45,45,40));

//Set line height 
$pdf -> SetLineHeight(5);



require_once('../assets/connection.php');
     $query = "SELECT * FROM course_details  ORDER BY Dept_ID,UG_PG_PhD,Course_Name ;";
     $result = mysqli_query($con,$query);
     
     if($result->num_rows>0){
      
        $i = 1;
        $row1 = "S.No";
        $row2 = "Dept ID";
        $row3 = "UG/PG/PhD";
        $row4 = "Course ID";
        $row5 = "Course Name";
        $row6 = "Intake";
        $row7 = "Course fee";
        $row8 = "Entered By";
        $row9 = "Entered Date and Time";
        $row10 = "Entered IP Address";

      while ($row = $result->fetch_assoc()) {
        
              

        $pdf ->SetFillColor(229,234,238);
        if($i>0){
         if ($i%2==0){
          $pdf ->SetFillColor(255,255,255);
         } else{
          $pdf ->SetFillColor(229,234,238);
         }
        }
        if ($i == 1){
          $pdf ->setFont('Roboto-Bold','B','12');
          $pdf ->SetTextColor(255,255,255);
          
          $pdf ->SetFillColor(0, 102, 102);
          $pdf->SetDrawColor(229,234,238);
          $pdf -> Row(Array(
            $row1,
            $row2,
            $row3,
            $row4,
            $row5,
            $row6,
            $row7,
            $row8,
            $row9,
            $row10,
          ));
   
               $pdf ->setFont('Roboto-Medium','','12');
               $pdf ->SetTextColor(0,0,0);
               $pdf ->SetFillColor(229,234,238);

        }
        $current_y = $pdf->GetY();
        // write data using Row method containing array af values.
        
        
        $pdf -> Row(Array(
          $i,
          $UniquedeptID[$i-1],
        //  $row['Dept_ID'],
          $row['UG_PG_PhD'],
          $row['Course_ID'],
          $row['Course_Name'],
          $row['Max_Student_Strength'],
          $row['Course_Fee'],
          $row['Entered_By'],
          $row['Date_and_Time'],
          $row['Enteded_IP_Adress'],
          
        ));

        
        
        
        if (($current_y>=180)&&($i<$result->num_rows)){
         // $pdf->AddPage('L');
                 
          $pdf ->SetFillColor(0, 102, 102);
          $pdf ->setFont('Roboto-Bold','B','12');
          // fill the heading background with this background color value
          $pdf ->SetTextColor(255,255,255);
        
          $pdf -> Row(Array(
            $row1,
            $row2,
            $row3,
            $row4,
            $row5,
            $row6,
            $row7,
            $row8,
            $row9,
            $row10,
          ));
   
               $pdf ->setFont('Roboto-Medium','','12');
               $pdf ->SetTextColor(0,0,0);
               // reset the background to white value
               $pdf ->SetFillColor(255,255,255);
              // $pdf->AliasNbPages();

        }
        
       /*
        $current_y = $pdf->GetY();
        //$field1name = $row["Department_name"];
        //echo "<option value= '".$field1name."'>".$field1name."</option>";
        $pdf->cell(25,10,$i,1,0,"C");
       $pdf->cell (34,10,$row["Department_ID"],1,0,"C");
      
       $pdf->cell (100,10,$row["Department_name"],1,0);
       $pdf->multicell (30,5,$row["Entered_date_and_Time"],1,1);// end of line
        //echo "<tr>";
        // echo "<td>".$i."</td>";
        // echo "<td>".$row["Department_ID"]."</td>";
       // echo "<td>".$row["Department_name"]."</td>";
        if ($current_y>260){
          $pdf ->setFont('Arial','B','12');
	
          $pdf->SetFillColor(209,207,207);	
          $pdf->cell(25,10,'S.No',1,0,"C",True);
           $pdf->cell (34,10,'Department ID',1,0,"C",True);
          $pdf->cell (100,10,'Department Name',1,0,"C",True);
          $pdf->multicell (30,5,'Entered Date and Time',1,1,"C",True);// end of line 

        }
       // echo "</tr>";
       */
       $pdf ->setFont('Roboto-Medium','','12');
        $i++;

    }
     }

     // Output the pdf 
     
     $pdf->Output();

/*

include('../../../Pdf/fpdf17/fpdf.php');

class PDF extends FPDF
{
function Footer()
{
    // Go to 1.5 cm from bottom
    $this->SetY(-15);
    // Select Arial italic 8
    $this->SetFont('Arial','I',8);
    // Print centered page number
   // $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C'); // value of page no alone 
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C'); // value of page no and total no of pages.
}
}

// $pdf = new FPDF('p','mm','A4');
 $pdf = new PDF('p','mm','A4');
// $pdf = new PDF();
 $pdf->AliasNbPages();
 //$pdf->AddPage();

 $pdf ->addpage();
 
 
 $pdf ->setFont('Arial','B','14');
 $pdf ->SetTextColor(167,70,141);
 $pdf->cell(189,5,'Department Name List',0,1,"C");
 // end of line

 

$pdf ->setFont('Arial','','12');
$pdf ->SetTextColor(167,70,141);


$pdf ->SetDrawColor(167,70,141);
 $pdf->cell(130,5,'',0,0);
 $pdf->cell (59,5,'',0,1); // end of line
 

 
 

    
   
     require_once('../../../connection.php');
     $query = "SELECT * FROM department_details ;";
     $result = mysqli_query($con,$query);
     if($result->num_rows>0){
        $i = 1;
      while ($row = $result->fetch_assoc()) {
        if ($i == 1){
          $pdf ->setFont('Arial','B','12');
	
          $pdf->SetFillColor(209,207,207);	
           $pdf->cell(25,10,'S.No',1,0,"C",True);
            $pdf->cell (34,10,'Department ID',1,0,"C",True);
           $pdf->cell (100,10,'Department Name',1,0,"C",True);
            $pdf->multicell (30,5,'Entered Date and Time',1,1,"C",True);// end of line 
               $pdf ->setFont('Arial','','12');

        }
        
        $current_y = $pdf->GetY();
        //$field1name = $row["Department_name"];
        //echo "<option value= '".$field1name."'>".$field1name."</option>";
        $pdf->cell(25,10,$i,1,0,"C");
       $pdf->cell (34,10,$row["Department_ID"],1,0,"C");
      
       $pdf->cell (100,10,$row["Department_name"],1,0);
       $pdf->multicell (30,5,$row["Entered_date_and_Time"],1,1);// end of line
        //echo "<tr>";
        // echo "<td>".$i."</td>";
        // echo "<td>".$row["Department_ID"]."</td>";
       // echo "<td>".$row["Department_name"]."</td>";
        if ($current_y>260){
          $pdf ->setFont('Arial','B','12');
	
          $pdf->SetFillColor(209,207,207);	
          $pdf->cell(25,10,'S.No',1,0,"C",True);
           $pdf->cell (34,10,'Department ID',1,0,"C",True);
          $pdf->cell (100,10,'Department Name',1,0,"C",True);
          $pdf->multicell (30,5,'Entered Date and Time',1,1,"C",True);// end of line 

        }
       // echo "</tr>";
       $pdf ->setFont('Arial','','12');
        $i++;

    }
     }

    /*             Wrap text in php cell
     $value = "hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii";
     $length= strlen($value);
     $y = 130;
     $mod = fmod($length,$y);
     $numerator = floor($length/$y); 
     if($mod == 0){
      $total = $numerator;
     }
     else{
      $total = $numerator+1;
     }
     //$total = $numerator+1;
     $width = 5*$total;
     $pdf->cell(25,$width,$i,1,0,"C");
     $pdf->cell (34,$width,$row["Department_ID"],1,0,"C");
     $pdf->multicell (130,5,$value,1,1);// end of line

     
     $value = "hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii";
     $pdf->cell(25,10,$i,1,0,"C");
     $pdf->cell (34,10,$row["Department_ID"],1,0,"C");
     $pdf->multicell (130,5,$value,1,1);// end of line
*/
/*
 $pdf->Output();
?>

*/