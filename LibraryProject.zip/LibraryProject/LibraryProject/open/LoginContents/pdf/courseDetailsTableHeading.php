
<?php

   //$table=new easyTable($pdf, '{20, 60, 20, 22,120,25,30,50,60,45}','align:C; valign:M;border:1; border-color:#e5eaee; ');
  // $table->rowStyle('align:C; valign:M;bgcolor:#006666; font-color:#ffffff; font-family:Roboto-Bold; font-style:B;');
  $table->rowStyle('align:C; valign:M;bgcolor:#fff; font-color:#000; font-family:Roboto-Bold; font-style:B;');
   $table->easyCell('S.No','align:C; valign:M');
   $table->easyCell('Dept Name','align:C; valign:M');
   $table->easyCell('UG/ PG/ PhD','align:C; valign:M');
   $table->easyCell('Course ID','align:C; valign:M');
   $table->easyCell('Course Name','align:C; valign:M');
   $table->easyCell('Intake','align:C; valign:M');
   $table->easyCell('Course fee','align:C; valign:M');
   $table->easyCell('Entered By','align:C; valign:M');
   $table->easyCell('Entered Date and Time','align:C; valign:M');
   $table->easyCell('Entered IP Address','align:C; valign:M');
   $table->printRow();

?>
