
<?php include '../../assets/connection.php';?>

<?php
session_start();
//fetch.php
//$connect = mysqli_connect("localhost", "root", "", "testing");
$columns = array('S_No','First_Name','Last_Name', 'Address','Phone_no','Email');

$query = "SELECT * FROM resume_experience_roles1  ";
//$query = "SELECT * FROM resume_header WHERE Profile_ID = '".$_SESSION['UserId']."'";
//$query = "SELECT * FROM resume_header WHERE Profile_ID = 3;";

if(isset($_POST["search"]["value"]))
{
 $query .= '
 WHERE roles_and_responsibilities LIKE "%'.$_POST["search"]["value"].'%" 
 OR company_id_experience LIKE "%'.$_POST["search"]["value"].'%" 
 ';
}

if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' 
 ';
}
else
{
 $query .= "ORDER BY company_id_experience DESC ";
}

$query1 = '';

if($_POST["length"] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));

$result = mysqli_query($connect, $query . $query1);

$data = array();


$S_No = $number_filter_row - $_POST['start'];
while($row = mysqli_fetch_array($result))
{
    $query1  = "SELECT * FROM resume_experience1 where id =";
    $query1 .= $row["company_id_experience"];
    $query1 .=";" ;
    $result1 = mysqli_query($connect, $query1 );
    while($row1 = mysqli_fetch_array($result1)){
         $Company_Name = $row1["Company_Name"];
    }
    
    if ($row["Profile_ID"]==$_SESSION['UserId']){
        $sub_array = array();
//  $sub_array[] = '<div contenteditable ="false" class="update" data-id="'.$row["id"].'" data-column="S_No">' . $S_No . '</div>';
 $sub_array[] = '<div contenteditable ="false" class="update" data-id="'.$row["id"].'" data-column="company_id_experience">' .$Company_Name . '</div>';
 $sub_array[] = '<div contenteditable ="true"  class="update" data-id="'.$row["id"].'" data-column="roles_and_responsibilities">' . $row["roles_and_responsibilities"] . '</div>';
// $sub_array[] = '<div contenteditable ="true" class="update" data-id="'.$row["id"].'" data-column="Designation">' . $row["Designation"] . '</div>';
// $sub_array[] = '<div contenteditable ="true" class="update" data-id="'.$row["id"].'" data-column="Worked_From">' .  $row["Worked_From"] . '</div>';
//   if($row["worked_Until"] =='0000-00-00'){
//     $sub_array[] = '<div contenteditable ="true" class="update" data-id="'.$row["id"].'" data-column="worked_Until">' . "until now" . '</div>';

//   }else{
//     $sub_array[] = '<div contenteditable ="true" class="update" data-id="'.$row["id"].'" data-column="worked_Until">' . $row["worked_Until"] . '</div>';

//   }

 $sub_array[] = '<button type="button" name="rolesDelete" class=" btn btn-outline-secondary glyphicon glyphicon-trash btn-xs rolesDelete"   id="'.$row["id"].'"><i class="fas fa-trash"></i> Delete</button>';
 //$sub_array[] = '<button type="button" name="delete" class="btn btn-default btn-sm glyphicon glyphicon-trash" Department_ID="'.$row["Department_ID"].'">  <span class=""></span> Trash </button>';
 $data[] = $sub_array;
 $S_No--;

    }
 
}

function get_all_data($connect)
{
 $query = "SELECT * FROM resume_experience_roles1 ";
 //$query = "SELECT * FROM resume_header WHERE Profile_ID = 3";
 $result = mysqli_query($connect, $query);
 return mysqli_num_rows($result);
}

$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  get_all_data($connect),
 "recordsFiltered" => $number_filter_row,
 "data"    => $data
);

echo json_encode($output);
//echo json_encode($data,JSON_PRETTY_PRINT);
?>


