
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["Company_id"]))
{
 $Company_id = mysqli_real_escape_string($connect, $_POST["Company_id"]);
 $roles_and_responsibilities = mysqli_real_escape_string($connect, $_POST["roles_and_responsibilities"]);
//  $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
//  $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
//  $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
//  $PresentlyWorking = mysqli_real_escape_string($connect, $_POST["vehicle1"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes

$query = "select * from resume_experience_roles1 where Profile_ID = '$Profile_ID' and company_id_experience = ' $Company_id' and roles_and_responsibilities = '$roles_and_responsibilities';";
 //$query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
 $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
 if ($number_filter_row ==0){

    $query = "INSERT ignore INTO resume_experience_roles1 (company_id_experience,roles_and_responsibilities,  Profile_ID) VALUES(trim(' $Company_id'),trim('$roles_and_responsibilities'),trim('$Profile_ID'))";
 
    if(mysqli_query($connect, $query))
    {
    echo 'Role / Responsibility  added  Successfully you can add your another role/responsibility of the same same company';
     //echo $PresentlyWorking;
     
    }
    else{
       // echo 'Department Name already exists';
        echo  "Refresh your browser and try again";
    }

 }
else{
    echo "Roles and Responsibitity already exist in the list";
}




//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 
}
//echo $_SESSION['UserId'];;
?>




