
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["First_Name"]))
{
 $Company_Name = mysqli_real_escape_string($connect, $_POST["First_Name"]);
 $Company_Location = mysqli_real_escape_string($connect, $_POST["Last_Name"]);
 $Designation = mysqli_real_escape_string($connect, $_POST["Address"]);
 $Worked_From = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
 
$worked_Until = mysqli_real_escape_string($connect, $_POST["Email"]);
 
 
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes


$query1 = "select * from resume_experience1 where Profile_ID = '$Profile_ID' and Company_Name = '$Company_Name' and Company_Location = '$Company_Location' and Designation = '$Designation' and Worked_From ='$Worked_From' and worked_Until ='$worked_Until'";
$result1 = mysqli_query($connect, $query1);
if($row = mysqli_fetch_array($result1)){
    echo  "Basic Details Already Entered. Please Update the existing record";
}else{
    $query = "INSERT ignore INTO resume_experience1 (Company_Name, Company_Location, Designation, Worked_From, worked_Until,  Profile_ID) VALUES(trim('$Company_Name'),trim('$Company_Location'),trim('$Designation'),trim('$Worked_From'),trim('$worked_Until'),trim('$Profile_ID'))";
 
 if(mysqli_query($connect, $query))
 {
 echo 'Data Inserted Successfully';
  //echo $PresentlyWorking;
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Basic Details Already Entered. Please Update the existing record";
 }
}



//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 
}
//echo $_SESSION['UserId'];;
?>




