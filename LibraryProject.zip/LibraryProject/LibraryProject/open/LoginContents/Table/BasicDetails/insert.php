
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["First_Name"]))
{
 $First_Name = mysqli_real_escape_string($connect, $_POST["First_Name"]);
 $Last_Name = mysqli_real_escape_string($connect, $_POST["Last_Name"]);
 $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
 $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
 $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes


// $query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
// $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
// if ($number_filter_row = =)



//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT INTO resume_header1 (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Basic Details Already Entered. Please Update the existing record";
 }
}
//echo $_SESSION['UserId'];;
?>




