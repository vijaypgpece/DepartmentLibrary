
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["Certification_Name"]))
{
 $Certification_Name = mysqli_real_escape_string($connect, $_POST["Certification_Name"]);
 $Certificate_description = mysqli_real_escape_string($connect, $_POST["Certificate_description"]);
 $issued_by = mysqli_real_escape_string($connect, $_POST["issued_by"]);
 $issued_date = mysqli_real_escape_string($connect, $_POST["issued_date"]);
 //$Email = mysqli_real_escape_string($connect, $_POST["Email"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes


// $query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
// $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
// if ($number_filter_row = =)


$query1 = "select * from resume_certification where Profile_ID = '$Profile_ID' and Title = '$Certification_Name' and Description = '$Certificate_description' and Issue_Date ='$issued_date' and Issued_By = '$issued_by'";
$result1 = mysqli_query($connect, $query1);
if($row = mysqli_fetch_array($result1)){
    echo  "Basic Details Already Entered. Please Update the existing record";
}else{
//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT INTO resume_certification ( Profile_ID, Title, Description, Issue_Date, Issued_By) VALUES(trim('$Profile_ID'),trim('$Certification_Name'),trim('$Certificate_description'),trim('$issued_date'),trim('$issued_by'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Basic Details Already Entered. Please Update the existing record";
 }

}


}
//echo $_SESSION['UserId'];;
?>




