
<?php include '../../assets/connection.php';?>
<?php

//$connect = mysqli_connect("localhost", "root", "", "testing");

if(isset($_POST["id"]))
{
 $query = "DELETE FROM resume_summary1 WHERE id = '".$_POST["id"]."'";
 if(mysqli_query($connect, $query))
 {
  echo 'Summary Deleted Successfully';
 }
 else{
     echo 'error';
 }
}
?>