
 <?php include '../../assets/connection.php';?>

<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["Summary"]))
{
 $Summary =trim(mysqli_real_escape_string($connect, $_POST["Summary"])) ;
//  $Last_Name = mysqli_real_escape_string($connect, $_POST["Last_Name"]);
//  $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
//  $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
//  $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes

//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT INTO resume_summary1 (Profile_ID, Summary)  VALUES('$Profile_ID',trim('$Summary'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Content for Summary Already Entered. Please Update the existing record";
 }
}
//echo $_SESSION['UserId'];;
?>




