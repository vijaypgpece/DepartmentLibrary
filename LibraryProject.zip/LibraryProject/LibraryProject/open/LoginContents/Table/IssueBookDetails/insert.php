
<?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["EmpCode"]))
{
 $EmpCode = mysqli_real_escape_string($connect, $_POST["EmpCode"]);
 $BookNum = mysqli_real_escape_string($connect, $_POST["BookNum"]);
 $BookAccessNum = mysqli_real_escape_string($connect, $_POST["BookAccessNum"]);
//  $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
//  $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
//  $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
//  //$Profile_ID = $_SESSION['UserId'];
//  //$enteredBy= $_SESSION['originalName'];
 //$Profile_ID =  $_SESSION['UserId'];
  
//test codes


// $query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
// $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
// if ($number_filter_row = =)

$query = "select * from departmentlibrarybookdetails where AccessNo = '$BookAccessNum' and BookNo = $BookNum";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {
 $bookID= $row['id'];
}

$query1 = "select * from studentdetails where RegisterNo_EmpCode = $EmpCode";
$result = mysqli_query($con,$query1);
while ($row = $result->fetch_assoc()) {
 $EmpID= $row['id'];
}




// $query1 = "select * from resume_languages1 where Profile_ID = '$Profile_ID' and Languages = '$First_Name' ";
// $result1 = mysqli_query($connect, $query1);
if(is_null($bookID) or is_null($EmpID) ){
    echo  $EmpID;
}else{
    $query = "INSERT INTO issuedetailsbook ( book_id, stud_id, issue_date_time, status) VALUES(trim('$bookID'),trim('$EmpID'),now(),'out')";
 
    if(mysqli_query($connect, $query))
    {
     echo 'Data Inserted Successfully';
     
    }
    else{
       // echo 'Department Name already exists';
        echo  "Basic Details Already Entered. Please Update the existing record";
    }
   }

$query = "SELECT s.Faculty_or_Student as StudentCode,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo
FROM issuedetailsbook i
JOIN departmentlibrarybookdetails d ON i.book_id= d.id
JOIN studentdetails s on i.stud_id = s.id";



}
//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 
//echo $_SESSION['UserId'];;
?>




