
<?php include '../../assets/connection.php';?>
<?php

//$connect = mysqli_connect("localhost", "root", "", "testing");

if(isset($_POST["id"]))
{
 $query = "DELETE FROM resume_languages1 WHERE id = '".$_POST["id"]."'";
 if(mysqli_query($connect, $query))
 {
  echo 'Data Deleted';
 }
 else{
     echo 'error';
 }
}
?>