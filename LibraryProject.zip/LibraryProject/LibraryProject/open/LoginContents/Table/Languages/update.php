
<?php include '../../assets/connection.php';?>
<?php
session_start();
//$enteredBy= $_SESSION['originalName'];
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["id"]))
{
 $value = mysqli_real_escape_string($connect, $_POST["value"]);
 $value= trim($value);
 $column_name = mysqli_real_escape_string($connect, $_POST["column_name"]);
  $id=$_POST["id"];
//  $query = "UPDATE resume_header SET ";
//  $query .=$column_name;
//  $query .="=trim('";
//  $query .=$value;
//  $query .="') WHERE id = ";
//  $query .=$_POST["id"];
$query= "update resume_languages1 SET $column_name = trim('$value') where id =  $id";
// $query = "UPDATE department_details SET Department_name = ".$_POST["column_name"].", Entered_by = 'me', Entered_date_and_Time = now()  WHERE Department_ID = '332'";
// $query = "update resume_header SET";
// $query .= $column_name;
// $query .= " = '";
// $query .= $value;
// $query .="' where id =" ;
// $query .=$_POST["id"];
//$query .="";";





 if(mysqli_query($connect, $query))
 {
  echo 'Data Updated';
 }
 else {
     echo $_POST["id"];
 }
}
?>