
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["SkillHighlights"]))
{
 $SkillHighlights = mysqli_real_escape_string($connect, $_POST["SkillHighlights"]);
//  $Last_Name = mysqli_real_escape_string($connect, $_POST["Last_Name"]);
//  $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
//  $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
//  $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes




$query1 = "select * from resume_hobbies where Profile_ID = '$Profile_ID' and Hobbies = '$SkillHighlights' ";
$result1 = mysqli_query($connect, $query1);
if($row = mysqli_fetch_array($result1)){
    echo  "Software Already Entered.";
}else{
//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT ignore INTO resume_hobbies(Profile_ID,Hobbies)  VALUES('$Profile_ID',trim('$SkillHighlights'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "hobby Already Entered.";
 }
}

}
//echo $_SESSION['UserId'];;
?>




