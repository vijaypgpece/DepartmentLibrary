
<?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["AccessNo"]))
{
 $AccessNo = mysqli_real_escape_string($connect, $_POST["AccessNo"]);
 $BookNo = mysqli_real_escape_string($connect, $_POST["BookNo"]);
 $bookName = mysqli_real_escape_string($connect, $_POST["bookName"]);
 $Author = mysqli_real_escape_string($connect, $_POST["Author"]);
 $publisher = mysqli_real_escape_string($connect, $_POST["publisher"]);
 $BeroNo = mysqli_real_escape_string($connect, $_POST["BeroNo"]);
 $shelfNo = mysqli_real_escape_string($connect, $_POST["shelfNo"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 //$Profile_ID =  $_SESSION['UserId'];
  
//test codes


// $query = "INSERT INTO resume_header (First_Name, Last_Name, Address, Phone_no, Email,  Profile_ID) VALUES(trim('$First_Name'),trim('$Last_Name'),trim('$Address'),trim('$Phone_no'),trim('$Email'),trim('$Profile_ID'))";
// $number_filter_row = mysqli_num_rows(mysqli_query($connect, $query));
// if ($number_filter_row = =)


//$query1 = "select * from resume_education1 where Profile_ID = '$Profile_ID' and Degree = '$First_Name' and Course = '$Last_Name' and Year_of_Completion ='$Address' and University = '$Phone_no' and University_Location = '$Email' ";
$query1 = "select * from departmentlibrarybookdetails where  AccessNo = '$AccessNo'  ";
$result1 = mysqli_query($connect, $query1);
if($row = mysqli_fetch_array($result1)){
    echo  "Basic Details Already Entered. Please Update the existing record";
}else{
//end of test codes
//
 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT INTO departmentlibrarybookdetails (AccessNo,BookNo,NameOfBook,Authors,Publisher,BeroNo,ShelfNo) VALUES(trim('$AccessNo'),trim('$BookNo'),trim('$bookName'),trim(' $Author'),trim('$publisher'),trim('$BeroNo'),trim('$shelfNo'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Basic Details Already Entered. Please Update the existing record";
 }

}


}
//echo $_SESSION['UserId'];;
?>




