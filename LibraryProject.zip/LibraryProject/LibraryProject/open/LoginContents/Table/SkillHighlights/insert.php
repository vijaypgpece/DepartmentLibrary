
 <?php include '../../assets/connection.php';?>



<?php
// require_once('../../assets/IP-address.php');
session_start();
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["SkillHighlights"]))
{
 $SkillHighlights = mysqli_real_escape_string($connect, $_POST["SkillHighlights"]);
//  $Last_Name = mysqli_real_escape_string($connect, $_POST["Last_Name"]);
//  $Address = mysqli_real_escape_string($connect, $_POST["Address"]);
//  $Phone_no = mysqli_real_escape_string($connect, $_POST["Phone_no"]);
//  $Email = mysqli_real_escape_string($connect, $_POST["Email"]);
 //$Profile_ID = $_SESSION['UserId'];
 //$enteredBy= $_SESSION['originalName'];
 $Profile_ID =  $_SESSION['UserId'];
  
//test codes




$query1 = "select * from resume_skillhighlights1 where Profile_ID = '$Profile_ID' and SkillHighlights = '$SkillHighlights' ";
$result1 = mysqli_query($connect, $query1);
if($row = mysqli_fetch_array($result1)){
    echo  "Basic Details Already Entered. Please Update the existing record";
}else{
//end of test codes

 //$last_name = mysqli_real_escape_string($connect, $_POST["last_name"]);
 //$query = "INSERT INTO department_details (Department_name, Entered_date_and_Time, Entered_by, Entered_User_IP_Address) VALUES(' $Department_name', NOW(), '$enteredBy','$ip_address')";
 $query = "INSERT ignore INTO resume_skillhighlights1(Profile_ID,SkillHighlights)  VALUES('$Profile_ID',trim('$SkillHighlights'))";
 
 if(mysqli_query($connect, $query))
 {
  echo 'Data Inserted Successfully';
  
 }
 else{
    // echo 'Department Name already exists';
     echo  "Content for Summary Already Entered. Please Update the existing record";
 }
}

}
//echo $_SESSION['UserId'];;
?>




