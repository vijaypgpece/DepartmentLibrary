
<?php include '../../assets/connection.php';?>
<?php
session_start();
//$enteredBy= $_SESSION['originalName'];
//$connect = mysqli_connect("localhost", "root", "", "testing");
if(isset($_POST["id"]))
{
 $value = mysqli_real_escape_string($connect, $_POST["value"]);
 $column_name = mysqli_real_escape_string($connect, $_POST["column_name"]);
 $query = "UPDATE resume_software SET ".$column_name."='".$value."' WHERE id = '".$_POST["id"]."'";
// $query = "UPDATE department_details SET Department_name = ".$_POST["column_name"].", Entered_by = 'me', Entered_date_and_Time = now()  WHERE Department_ID = '332'";
// $query = "update resume_header SET";
// $query .= $column_name;
// $query .= " = '";
// $query .= $value;
// $query .="' where id =" ;
// $query .=$_POST["id"];
//$query .="";";





 if(mysqli_query($connect, $query))
 {
  echo 'Data Updated';
 }
 else {
     echo $_POST["id"];
 }
}
?>