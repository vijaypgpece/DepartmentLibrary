<?php 
session_start();
session_destroy();
header("location:../index.php");
if(isset($_GET['logout']))
{
    session_destroy();
    $_SESSION["loggedIn"] = false;
    header("location:../index.php");
}
?>