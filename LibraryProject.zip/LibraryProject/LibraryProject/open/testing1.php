<!DOCTYPE html>
<html lang="en">
<head>
    <title>Integrate datatable - Coding Birds Online</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script> -->
    <!-- <script src="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css"></script> -->
    <link   rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
    <style> #thead>tr>th{ color: white; } </style>
</head>
<body>
<div class="container">
    <table id="exampleTable" class="table table-striped table-bordered" style="width: 100%">

    <thead id="thead">
        <tr style="background-color: #1573ff">
            <th>Name</th>
            <th>Emp Code/Reg No</th>
            <th>Access No</th>
            <th>Book No</th>
            <th>Book Name</th>
            <th>Issue Date & Time</th>            
            <th>Return Date</th>
        </tr>
        </thead>
        <tbody>
        <tr>
        <?php include 'LoginContents/assets/connection.php';?>


<?php

$query = "SELECT s.Faculty_or_Student as StudentCode,d.NameOfBook as BookName,i.issue_date_time as issueDate, i.return_date_time as returnDate, d.AccessNo as accessNo,d.BookNo as bookNo,s.RegisterNo_EmpCode as RegOrEmpNum,s.Name as Name,s.email as email,s.Mobile_No as mobNo,i.id as issueId
FROM issuedetailsbook i
JOIN departmentlibrarybookdetails d ON i.book_id= d.id
JOIN studentdetails s on i.stud_id = s.id 
order by returnDate asc";

//$query = "select * from departmentlibrarybookdetails where AccessNo = '$BookAccessNum' and BookNo = $BookNum";
$result = mysqli_query($con,$query);
while ($row = $result->fetch_assoc()) {
    echo '<tr>';
    echo '<td>'.$row['Name'].'</td>';
    echo '<td>'.$row['StudentCode'].'</td>';
    echo '<td>'.$row['accessNo'].'</td>';
    echo '<td>'.$row['bookNo'].'</td>';
    echo '<td>'.$row['BookName'].'</td>';
    echo '<td>'.$row['issueDate'].'</td>';
    if(isset($row['returnDate'])){
        echo '<td>'.$row['returnDate'].'</td>';

    }
else{
    echo '<td><button type="button" class="btn btn-outline-primary"';
    echo 'onclick="window.open(';
    echo "'../return.php?issueID=".$row['issueId']."')";
 echo ' ">Return Book No: '.$row['bookNo'].'</button>';
}
echo '</tr>';
}

?>




       
            
            
 </td>
     
        </tr>
      
        
        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Emp Code/Reg No</th>
            <th>Access No</th>
            <th>Book No</th>
            <th>Book Name</th>
            <th>Issue Date & Time</th>            
            <th>Return Date</th>
        </tr>
        </tfoot>
    </table>
</div>
<script>
    $(document).ready(function() {
        $('#exampleTable').DataTable();
    } );
</script>
</body>
</html>